# শেষ শিফট · THE LAST SHIFT

**An offline, Bengali/English survival-horror game for Android.**

Five CCTV cameras. One security door. A limited backup battery. Survive a four-minute shift in a fictional abandoned Dhaka factory, from midnight to 6 AM.

![The Last Shift — Bengali menu](docs/menu.jpg)

![Surveillance camera gameplay](docs/cameras.jpg)

## এই সংস্করণে যা আছে

- অফলাইন Android APK; কোনো অ্যাকাউন্ট, বিজ্ঞাপন বা ইন-অ্যাপ কেনাকাটা নেই।
- বাংলা / English ভাষা বদলানো যায়।
- ৫টি আলাদা CCTV দৃশ্য, ২ ধরনের বিপদ, দরজার লক ও ধরে রাখার টর্চ।
- সীমিত বিদ্যুৎ; ক্যামেরায় নজর রাখলে ছায়া ধীরে এগোয়।
- ৩টি গল্পের নথি ও ২টি সফল সমাপ্তি।
- শব্দ চালু/বন্ধ, কম অ্যানিমেশন, পজ ও ডিভাইসে সংরক্ষিত রেকর্ড।
- ডেস্কটপ ব্রাউজার, মোবাইল টাচ ও Android landscape layout।

This is a **first playable, single-night release**, not a multi-level commercial game. All characters, factory names and incidents are fictional. Contains spooky silhouettes, mild flicker and sudden sounds; no gore. The field manual includes sound and reduced-motion settings.

## Install the APK

1. Copy/download `release/Last-Shift-1.0.0.apk` to an Android phone.
2. Open it using your browser or Files app. If Android asks, allow **Install unknown apps** for that app, only if you trust this build. You can revoke that permission afterward.
3. Install **শেষ শিফট** and open it. Rotate to landscape; the Android host requests landscape automatically.
4. Read **গার্ডের নির্দেশিকা / Field manual**, then begin a shift.

Declared minimum: **Android 7.0 (API 24)**; a reasonably recent **Android System WebView** is recommended. Target/compile SDK: 35. The APK has **no Android permissions**, including no Internet permission. All code, fonts, art and audio generation are bundled.

The supplied APK is signed with a **development/test key**, not a Play Store production key. If a later build uses a different signing key, Android will require uninstalling the old build first; uninstalling clears local records. Do not bypass Play Protect warnings or turn off device security globally.

Verify the download on a computer:

```bash
cd release
sha256sum -c APK-SHA256.txt
```

## How to play

Your goal is to reach **06:00**. One entire night takes **240 real seconds**.

| Control | Touch | Keyboard |
| --- | --- | --- |
| CCTV monitor | Tap Cameras | `C` |
| Change camera | Tap camera list, map or quick selector | `1`–`5` |
| Door lock | Tap Security door | `E` |
| Flashlight | Press and hold Flashlight | Hold `Space` |
| Pause | Top-right pause icon | `Esc` |
| Evidence | Tap the document notification | Click / keyboard-focus the notification |

- **The shadow** follows cameras **01 → 02 → 03 → 05**. Watching its current feed slows it down. Lock the door when the door sensor reports footsteps. After about three seconds the sensor clears; unlock to save power.
- **The whisper** comes through the ventilation. Hold the flashlight for about three seconds when the vent sensor reports scraping. The flashlight lowers the monitor automatically. The door cannot stop this threat.
- You can lock the door and use the light simultaneously. Audio is helpful but **not required**: both threats have visible sensor and warning cues.
- The monitor, lock and light consume power. Permanently locking the door is not a viable strategy.
- Documents appear over the course of the night. Read all three and survive for the alternate ending. Reading and pausing stop the clock and power drain.
- App backgrounding pauses the game. An interrupted shift is **not** restored after the process is killed. Completed results and preferences are kept locally, not synced.

## Play in a browser

No frontend build step or runtime dependencies:

```bash
python3 -m http.server 8000 --bind 0.0.0.0 --directory game
```

Then open `http://localhost:8000`. `npm start` runs the same command. This source does not include a service worker: a fresh browser load requires access to the files/server; the Android APK itself is fully offline.

## Build an APK on Linux

Requirements: **JDK 11 or 17**, **Python 3.9+**, and `zip`. No Android Studio, Gradle or npm packages are required for APK compilation.

```bash
# Review the Android SDK terms, then explicitly accept them to download
# the pinned official Google platform and build-tools packages (~125 MB).
python3 tools/setup_sdk.py --accept-license

# Package, sign, zipalign and verify:
bash tools/build-apk.sh
```

Output:

- `release/Last-Shift-1.0.0.apk`
- `release/APK-SHA256.txt`

The setup uses `ANDROID_SDK_ROOT`, then `ANDROID_HOME`, otherwise `~/.cache/last-shift/android-sdk`. Build-tools **34.0.0** and platform **android-35** are pinned and download checksums are verified. The build script discovers `JAVA_HOME` from `javac` if needed.

For your own production signing key, set:

```bash
export LASTSHIFT_KEYSTORE=/absolute/path/to/your-key.jks
export LASTSHIFT_KEY_ALIAS=your-alias
# Set LASTSHIFT_STORE_PASSWORD and LASTSHIFT_KEY_PASSWORD privately.
# Never commit signing keys or passwords.
bash tools/build-apk.sh
```

Without these settings a local development key is created in `.signing/`. Keep it safe if you want compatible updates. It is ignored by Git and excluded from the source distribution.

## GitHub repository

**No remote GitHub repository has been created by this delivery.** This directory is ready to upload, including `.github/workflows/android.yml`. You need an authenticated GitHub account to create the remote.

Recommended repository name: `last-shift`.

Using GitHub CLI on your own computer after extracting the source ZIP:

```bash
cd last-shift
git init -b main
git add .
git commit -m "Initial playable Last Shift game"
gh auth login
gh repo create last-shift --private --source=. --remote=origin --push
```

Change `--private` to `--public` only if you intend to publish the code. Configure your Git author name/email locally if Git asks. Do not send access tokens in chat.

Alternatively, create an empty repository in GitHub, then use its displayed push instructions. Preserve the `.github` directory when uploading. The **Build Android APK** workflow runs rule tests and produces a downloadable signed test APK under the workflow run’s **Artifacts**. It does not automatically create a GitHub Release or upload to the Play Store. Each clean CI run generates a fresh test signing key unless you configure your own signing workflow.

## Tests

Game-rule tests require only Node.js 20+:

```bash
npm test
```

Optional browser checks (run the local server first):

```bash
npm ci
npx playwright install --with-deps chromium
npm run test:browser
```

The browser suite checks localization, keyboard/pointer controls, pause behavior, documents, threat defenses, endings, persistence, responsive layouts and absence of third-party network requests. `tests/package.test.py` checks the compiled APK’s bundled assets and verifies that all source assets match the packaged copies.

Validation details and device-testing limitations are in `QA.md`.

## Project layout

```text
game/                         Self-contained HTML/CSS/JavaScript + local assets
  engine.js                   DOM-independent, substepped simulation
  app.js                      UI, Bangla/English text, input, local storage
  audio.js                    Original Web Audio sound synthesis
  scenes.js                   Original SVG CCTV environments
android/app/src/main/         Minimal Java WebView host, manifest, resources
tools/                        Pinned SDK installer and APK assembly/signing script
tests/                        Engine, browser and APK-content checks
.github/workflows/android.yml GitHub Actions build workflow
release/                      Built APK and checksum (not committed)
```

## Privacy, credits and licensing

No analytics, accounts, advertisements, remote fonts or network APIs. Records and settings live in WebView/browser local storage. Clearing app data or uninstalling deletes them. The host blocks network loads and does not request Internet permission.

Code is provided under the MIT license. The security-office environment image was AI-generated for this project. CCTV environments, UI icon drawings and sound synthesis were created for this game. Bundled **Noto Sans Bengali**, **Barlow Condensed**, and **Space Mono** fonts are under their included SIL Open Font License files in `game/assets/`. See `CREDITS.md`.
