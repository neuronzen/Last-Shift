#!/usr/bin/env python3
"""Check that the APK really bundles the complete, current offline game."""
import hashlib
from pathlib import Path
import re
import os
import subprocess
import zipfile

root = Path(__file__).resolve().parent.parent
apk = root / 'release/Last-Shift-1.0.0.apk'
assert apk.is_file(), 'Build the APK first'
checks = 0
with zipfile.ZipFile(apk) as z:
    for path in sorted((root / 'game').rglob('*')):
        if path.is_file():
            name = 'assets/' + path.relative_to(root / 'game').as_posix()
            assert z.read(name) == path.read_bytes(), 'Packaged file differs from source: ' + name
            checks += 1
    assert z.read('classes.dex').startswith(b'dex\n'), 'Missing native host dex'
    checks += 1
    html = z.read('assets/index.html').decode('utf-8')
    for relative in re.findall(r'(?:src|href)="([^"#]+)"', html):
        assert not relative.startswith(('https:', 'http:', '//')), 'External runtime dependency'
        assert 'assets/' + relative in z.namelist(), 'Missing HTML resource: ' + relative
        checks += 1
manifest = (root / 'android/app/src/main/AndroidManifest.xml').read_text()
assert '<uses-permission' not in manifest, 'Unexpected Android permission'
checks += 1
sdk = Path(os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME', str(Path.home() / '.cache/last-shift/android-sdk'))))
aapt = sdk / 'build-tools/34.0.0/aapt2'
if aapt.is_file():
    permissions = subprocess.check_output([str(aapt), 'dump', 'permissions', str(apk)], text=True)
    assert 'uses-permission' not in permissions, 'Compiled APK requests a permission'
    checks += 1
checksum = (root / 'release/APK-SHA256.txt').read_text().split()[0]
assert hashlib.sha256(apk.read_bytes()).hexdigest() == checksum, 'APK checksum mismatch'
checks += 1
print(f'{checks} APK asset, permission and checksum checks passed. ({apk.stat().st_size:,} bytes)')
