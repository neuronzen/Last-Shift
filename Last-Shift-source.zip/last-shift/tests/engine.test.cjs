const test = require('node:test');
const assert = require('node:assert/strict');
const { ShiftEngine } = require('../game/engine.js');
const create = () => { const e = new ShiftEngine({ random: () => 0.5 }); e.start(); e.drainEvents(); return e; };
const near = (actual, expected, tolerance = 1e-6) => assert.ok(Math.abs(actual - expected) < tolerance, `${actual} != ${expected}`);

test('a ready game does not advance', () => {
  const e = new ShiftEngine(); e.tick(10); assert.equal(e.state.elapsed, 0); assert.equal(e.state.status, 'ready');
});
test('clock maps four real minutes to six game hours', () => {
  const e = create(); e.tick(10); assert.equal(e.clock, '00:15'); near(e.state.power, 98.95);
});
test('monitor draws extra power', () => {
  const e = create(); e.toggleMonitor(); e.tick(10); near(e.state.power, 97.8); assert.equal(e.usage,2);
});
test('flashlight automatically lowers the monitor', () => {
  const e = create(); e.toggleMonitor(); e.setFlashlight(true); assert.equal(e.state.monitor,false); assert.equal(e.state.flashlight,true); e.setFlashlight(false); assert.equal(e.state.flashlight,false);
});
test('invalid cameras and closed-monitor selections are ignored', () => {
  const e = create(); assert.equal(e.selectCamera(4),false); e.toggleMonitor(); for(const id of [-1,5,1.5,NaN]) assert.equal(e.selectCamera(id),false); assert.equal(e.selectCamera(3),true); assert.equal(e.state.camera,3);
});
test('watching the occupied camera slows the shadow', () => {
  const watched=create(),other=create();
  for(const e of [watched,other]){e.state.shadow.stage=0;e.state.shadow.timer=10;e.toggleMonitor();}
  other.selectCamera(1);watched.tick(5);other.tick(5);
  near(watched.state.shadow.timer,9.1);near(other.state.shadow.timer,5);
});
test('a locked door repels the shadow after about three seconds', () => {
  const e=create();e.state.shadow.stage=3;e.state.shadow.attack=8;e.toggleDoor();e.tick(2.9);
  assert.equal(e.state.shadow.stage,-1);assert.equal(e.state.doorRepels,1);assert.equal(e.state.status,'running');
});
test('an open door eventually lets the shadow in', () => {
  const e=create();e.state.shadow.stage=3;e.state.shadow.attack=.5;e.tick(1);assert.equal(e.state.status,'lost');assert.equal(e.state.cause,'shadow');
});
test('holding the flashlight repels the vent threat', () => {
  const e=create();e.state.whisper.active=true;e.state.whisper.attack=10;e.setFlashlight(true);e.tick(2.4);
  assert.equal(e.state.whisper.active,false);assert.equal(e.state.ventRepels,1);
});
test('a locked door does not protect the ventilation', () => {
  const e=create();e.toggleDoor();e.state.whisper.active=true;e.state.whisper.attack=.5;e.tick(1);assert.equal(e.state.cause,'whisper');
});
test('the flashlight does not protect an open door', () => {
  const e=create();e.setFlashlight(true);e.state.shadow.stage=3;e.state.shadow.attack=.5;e.tick(1);assert.equal(e.state.cause,'shadow');
});
test('door and vent threats can be defended simultaneously', () => {
  const e=create();e.state.shadow.stage=3;e.state.shadow.attack=8;e.state.whisper.active=true;e.state.whisper.attack=10;e.toggleDoor();e.setFlashlight(true);e.tick(3);
  assert.equal(e.state.status,'running');assert.equal(e.state.shadow.stage,-1);assert.equal(e.state.whisper.active,false);
});
test('outage releases equipment, prevents actions, and has a grace period', () => {
  const e=create();e.state.power=.01;e.toggleMonitor();e.toggleDoor();e.tick(.2);
  assert.equal(e.state.outage,true);assert.equal(e.state.door,false);assert.equal(e.state.monitor,false);assert.equal(e.state.power,0);
  assert.equal(e.toggleDoor(),false);assert.equal(e.toggleMonitor(),false);assert.equal(e.setFlashlight(true),false);
  e.tick(17);assert.equal(e.state.status,'lost');assert.equal(e.state.cause,'power');
});
test('documents are time-gated and cannot be collected twice', () => {
  const e=create();e.toggleMonitor();assert.equal(e.collectNote(),-1);e.state.elapsed=16;assert.equal(e.collectNote(),0);assert.equal(e.collectNote(),-1);
  e.state.elapsed=74;e.selectCamera(2);assert.equal(e.collectNote(),1);e.state.elapsed=132;e.selectCamera(3);assert.equal(e.collectNote(),2);assert.deepEqual(e.state.notes,[0,1,2]);
});
test('pause freezes time and power and releases the light', () => {
  const e=create();e.setFlashlight(true);e.pause();const before={...e.state};e.tick(20);assert.equal(e.state.elapsed,before.elapsed);assert.equal(e.state.power,before.power);assert.equal(e.state.flashlight,false);assert.equal(e.toggleDoor(),false);assert.equal(e.collectNote(),-1);assert.equal(e.resume(),true);e.tick(1);assert.ok(e.state.elapsed>0);
});
test('surviving without all documents gives the dawn ending', () => {
  const e=create();e.state.elapsed=239.95;e.tick(.1);assert.equal(e.state.status,'won');assert.equal(e.state.ending,'dawn');assert.equal(e.clock,'06:00');
});
test('all three documents unlock the archive ending', () => {
  const e=create();e.state.elapsed=239.95;e.state.notes=[0,1,2];e.tick(.1);assert.equal(e.state.ending,'archive');
});
test('reaching dawn during a power outage can still win', () => {
  const e=create();e.state.elapsed=239;e.state.outage=true;e.state.outageTimer=2;e.tick(1.1);assert.equal(e.state.status,'won');
});
test('terminal states cannot change through equipment controls', () => {
  const e=create();e.lose('shadow');const elapsed=e.state.elapsed;e.tick(300);assert.equal(e.state.elapsed,elapsed);assert.equal(e.toggleDoor(),false);assert.equal(e.toggleMonitor(),false);
});
test('a large tick is equivalent to small substeps', () => {
  const a=create(),b=create();a.tick(25);for(let i=0;i<250;i++)b.tick(.1);
  near(a.state.elapsed,b.state.elapsed);near(a.state.power,b.state.power);near(a.state.shadow.timer,b.state.shadow.timer);assert.equal(a.state.shadow.stage,b.state.shadow.stage);
});
test('invalid deltas are ignored', () => {
  const e=create();for(const dt of [-1,0,NaN,Infinity])e.tick(dt);assert.equal(e.state.elapsed,0);
});
test('a normal reactive strategy can survive and collect every document', () => {
  for(let seed=1;seed<=12;seed++){
    let n=seed;const random=()=>{n=(n*1664525+1013904223)>>>0;return n/4294967296;};
    const e=new ShiftEngine({random});e.start();
    for(let i=0;i<2500&&e.state.status==='running';i++){
      const s=e.state;
      if((s.shadow.stage===3)!==s.door)e.toggleDoor();
      e.setFlashlight(s.whisper.active);
      for(const [id,cam,time] of [[0,0,16],[1,2,74],[2,3,132]]){
        if(s.elapsed>=time&&!s.notes.includes(id)&&!s.whisper.active){if(!s.monitor)e.toggleMonitor();e.selectCamera(cam);e.collectNote();if(s.monitor)e.toggleMonitor();}
      }
      e.tick(.1);e.drainEvents();
    }
    assert.equal(e.state.status,'won',`seed ${seed}: ${e.state.cause}`);assert.equal(e.state.ending,'archive');assert.ok(e.state.power>45,`power ${e.state.power}`);
  }
});
test('permanently locking the door is not a viable strategy', () => {
  const e=create();e.toggleDoor();e.toggleMonitor();
  for(let i=0;i<2500&&e.state.status==='running';i++){
    if(!e.state.outage){e.setFlashlight(e.state.whisper.active);if(!e.state.whisper.active&&!e.state.monitor)e.toggleMonitor();}
    e.tick(.1);
  }
  assert.equal(e.state.status,'lost');assert.equal(e.state.cause,'power');
});
