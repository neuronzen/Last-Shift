# Android build output

Run `bash tools/build-apk.sh` from the repository root.

The verified APK and SHA-256 checksum are generated here. APK binaries and signing keys are intentionally not committed to the source repository.

The separately delivered `Last-Shift-1.0.0.apk` is a development/test-signed build. Read `INSTALL-BN.md` and `QA.md` before installation.
