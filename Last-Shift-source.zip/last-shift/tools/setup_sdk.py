#!/usr/bin/env python3
"""Fetch a pinned minimal Linux Android SDK; no third-party download hosts."""
import argparse
import concurrent.futures
import hashlib
import os
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile

PACKAGES = [
    ('platforms/android-35', 'https://dl.google.com/android/repository/platform-35_r02.zip', '0bb560a90a7a2cbd0dd8348224d518b638fe7949'),
    ('build-tools/34.0.0', 'https://dl.google.com/android/repository/build-tools_r34-linux.zip', 'd6d58e0c6925a9e4d9a541e84cd1f405c2f9d2a9'),
]

def install(sdk, package):
    relative, url, sha1 = package
    destination = sdk / relative
    marker = destination / ('android.jar' if relative.startswith('platforms') else 'aapt2')
    if marker.is_file():
        print('Already installed:', relative)
        return
    with tempfile.TemporaryDirectory() as temp:
        archive = Path(temp) / 'sdk.zip'
        print('Downloading:', relative)
        urllib.request.urlretrieve(url, archive)
        if hashlib.sha1(archive.read_bytes()).hexdigest() != sha1:
            raise RuntimeError('SDK archive checksum failed: ' + relative)
        with zipfile.ZipFile(archive) as z:
            prefix = z.namelist()[0].split('/')[0] + '/'
            for member in z.infolist():
                name = member.filename[len(prefix):]
                if not name:
                    continue
                path = (destination / name).resolve()
                if not path.is_relative_to(destination.resolve()):
                    raise RuntimeError('Unsafe archive path')
                if member.is_dir():
                    path.mkdir(parents=True, exist_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(member) as source, path.open('wb') as output:
                        shutil.copyfileobj(source, output)
                    permission = member.external_attr >> 16
                    if permission:
                        path.chmod(permission)
        print('Installed:', relative)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', default=os.environ.get('ANDROID_SDK_ROOT', os.environ.get('ANDROID_HOME', str(Path.home() / '.cache/last-shift/android-sdk'))))
    parser.add_argument('--accept-license', action='store_true', help='Accept the Android SDK license at https://developer.android.com/studio/terms')
    args = parser.parse_args()
    if not args.accept_license:
        parser.error('Read https://developer.android.com/studio/terms and pass --accept-license if you agree.')
    sdk = Path(args.sdk).resolve()
    sdk.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda p: install(sdk, p), PACKAGES))
    print('SDK ready:', sdk)
