#!/usr/bin/env bash
# Linux + JDK 11/17 + Python 3 + zip. No Gradle or npm needed to build the APK.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/.cache/last-shift/android-sdk}}"
BT="$SDK/build-tools/34.0.0"
ANDROID_JAR="$SDK/platforms/android-35/android.jar"
BUILD="$ROOT/.cache/android-build"
RELEASE="$ROOT/release"
APK="$RELEASE/Last-Shift-1.0.0.apk"
# Some minimal JDK installations expose java/javac but not keytool on PATH.
if [[ -z "${JAVA_HOME:-}" ]] && command -v javac >/dev/null; then
    export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")"
fi
if [[ -n "${JAVA_HOME:-}" ]]; then export PATH="$JAVA_HOME/bin:$PATH"; fi
if [[ ! -x "$BT/aapt2" || ! -f "$ANDROID_JAR" ]]; then
    echo 'Android SDK components not found.' >&2
    echo 'Run: python3 tools/setup_sdk.py --accept-license' >&2
    exit 1
fi
for cmd in javac java keytool zip; do command -v "$cmd" >/dev/null || { echo "Missing command: $cmd" >&2; exit 1; }; done
rm -rf "$BUILD"
mkdir -p "$BUILD"/{classes,generated,dex} "$RELEASE"
echo '1/6 Compiling Android resources'
"$BT/aapt2" compile --dir "$ROOT/android/app/src/main/res" -o "$BUILD/resources.zip"
"$BT/aapt2" link -I "$ANDROID_JAR" \
    --manifest "$ROOT/android/app/src/main/AndroidManifest.xml" \
    -A "$ROOT/game" --java "$BUILD/generated" \
    -o "$BUILD/base.apk" "$BUILD/resources.zip" --auto-add-overlay

echo '2/6 Compiling native offline host'
find "$ROOT/android/app/src/main/java" "$BUILD/generated" -name '*.java' -print > "$BUILD/sources.txt"
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ANDROID_JAR" \
    -d "$BUILD/classes" @"$BUILD/sources.txt"
find "$BUILD/classes" -name '*.class' -print > "$BUILD/classes.txt"
mapfile -t CLASSES < "$BUILD/classes.txt"
"$BT/d8" --lib "$ANDROID_JAR" --min-api 24 --output "$BUILD/dex" "${CLASSES[@]}"

echo '3/6 Packaging offline game assets'
zip -q -j "$BUILD/base.apk" "$BUILD/dex/classes.dex"
"$BT/zipalign" -f -p 4 "$BUILD/base.apk" "$BUILD/aligned.apk"

echo '4/6 Signing APK'
KEYSTORE="${LASTSHIFT_KEYSTORE:-$ROOT/.signing/test-signing.jks}"
export LASTSHIFT_STORE_PASSWORD="${LASTSHIFT_STORE_PASSWORD:-android}"
export LASTSHIFT_KEY_PASSWORD="${LASTSHIFT_KEY_PASSWORD:-android}"
ALIAS="${LASTSHIFT_KEY_ALIAS:-androiddebugkey}"
if [[ ! -f "$KEYSTORE" ]]; then
    if [[ -n "${LASTSHIFT_KEYSTORE:-}" ]]; then echo 'Custom signing keystore not found.' >&2; exit 1; fi
    mkdir -p "$(dirname "$KEYSTORE")"
    keytool -genkeypair -keystore "$KEYSTORE" \
        -storepass:env LASTSHIFT_STORE_PASSWORD -keypass:env LASTSHIFT_KEY_PASSWORD \
        -alias "$ALIAS" -dname 'CN=Android Debug,O=Android,C=US' \
        -keyalg RSA -keysize 2048 -validity 10000 -noprompt
fi
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-key-alias "$ALIAS" \
    --ks-pass env:LASTSHIFT_STORE_PASSWORD --key-pass env:LASTSHIFT_KEY_PASSWORD \
    --out "$APK" "$BUILD/aligned.apk"

echo '5/6 Verifying package and signature'
"$BT/zipalign" -c -p 4 "$APK"
"$BT/apksigner" verify --verbose "$APK"
"$BT/aapt2" dump badging "$APK" | head -n 12

echo '6/6 Writing checksum'
(cd "$RELEASE" && sha256sum "$(basename "$APK")" > APK-SHA256.txt)
ls -lh "$APK"
echo "Ready: $APK"
