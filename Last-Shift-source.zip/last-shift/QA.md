# Last Shift 1.0.0 — validation notes

Build date: **2026-10-26 (Asia/Dhaka)**.

## Completed checks

| Area | Result |
| --- | --- |
| JavaScript syntax | All four scripts parse successfully |
| Node game-rule suite | **23 tests passed** |
| Chromium browser suite | **44 checks passed** |
| APK content suite | **24 checks passed** |
| Android resource/Java/dex compilation | Passed, using platform 35 and build-tools 34.0.0 |
| APK zip alignment | Passed |
| APK signature verification | Passed; v2 and v3 signatures, one test signer |
| APK contents against current source | Every bundled game file matches its source bytes |
| Local-file-origin execution | Extracted APK assets load, fonts load and game/camera controls work in Chromium without HTTP resources |
| Android permission declaration | None, including no Internet permission |

## Covered behavior

- Bengali default and English language toggle.
- Local preferences, attempt count, wins, best survived time and discovered endings.
- Keyboard controls, pointer press/hold/release, touch-emulated press/hold/release.
- Monitor automatically lowering when the flashlight is used.
- Camera selection from the list and always-visible touch quick selector.
- Time-gated evidence, document modal pausing, alternate-ending selection.
- Door and vent threat cues, successful repels and an actual browser failure path.
- Simultaneous threats, power outage, equipment limits and dawn during an outage.
- Pause freezing both the clock and power; manual navigation returning to pause.
- Native lifecycle/back JavaScript callbacks and retry resetting the night.
- A complete reactive survival strategy, including all three documents, against **12 deterministic random seeds**.
- Permanently locking the door is verified to fail through battery exhaustion.
- No JavaScript exceptions during the browser suite and no third-party resource requests.

## Layouts inspected

- Desktop: **1440 × 900**.
- Mobile landscape: **844 × 390**, including a touch-enabled DPR-2 browser context.
- Mobile portrait: **390 × 844** (browser support; Android requests landscape).
- APK-extracted file-origin game: **960 × 540**.

No horizontal overflow was detected at the tested mobile viewports. Small landscape screens can scroll the instrument sidebar; camera quick selectors remain inside the main viewport. Screenshots were visually reviewed. Capturing during the short camera-switch transition can show intentional static.

## Important limits

- **The APK has not been installed or run on a physical Android phone or Android emulator in this environment.** Compiling, signature verification, browser touch emulation and loading APK-extracted assets are not substitutes for device testing.
- Device-specific WebView behavior, audio latency, display cutouts, native back navigation and performance still require testing on the target phone.
- This is one four-minute night, not a finished multi-night/store-ready commercial product.
- A reasonably recent device-compatible Android System WebView is needed for modern JavaScript/CSS. The manifest declares API 24 minimum; this does not guarantee compatibility with an unupdated Android 7 WebView.
- The APK uses a development/test signing key. Production publishing requires your own stable signing configuration and review of current store requirements.
- No remote GitHub repository was created; repository-ready source and a build workflow are supplied.

## Re-run

```bash
npm test
# Start the server in another terminal:
# python3 -m http.server 8000 --bind 0.0.0.0 --directory game
npm ci
npx playwright install --with-deps chromium
npm run test:browser
bash tools/build-apk.sh
python3 tests/package.test.py
```
