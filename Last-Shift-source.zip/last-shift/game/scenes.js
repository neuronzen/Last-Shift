/* Original SVG set design. Each camera is rendered locally, without network assets. */
"use strict";
(function () {
  const defs = `<defs>
    <linearGradient id="wall" x1="0" x2="0" y2="1"><stop stop-color="#343d32"/><stop offset="1" stop-color="#101b13"/></linearGradient>
    <linearGradient id="floor" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#141c15"/><stop offset="1" stop-color="#384133"/></linearGradient>
    <linearGradient id="side" x1="0" x2="1"><stop stop-color="#101a12"/><stop offset="1" stop-color="#3b4838"/></linearGradient>
    <radialGradient id="glow"><stop stop-color="#d6e7b1" stop-opacity=".3"/><stop offset="1" stop-color="#d6e7b1" stop-opacity="0"/></radialGradient>
    <radialGradient id="vignette"><stop offset=".25" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".8"/></radialGradient>
    <filter id="rough"><feTurbulence type="fractalNoise" baseFrequency=".45" numOctaves="3" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter>
  </defs>`;
  function figure(x, y, scale, vent = false) {
    if (vent)
      return `<g transform="translate(${x} ${y}) scale(${scale})"><ellipse cx="0" cy="0" rx="49" ry="55" fill="#020703"/><path d="M-30 24Q-95 23-135 100M30 24Q95 23 135 100" stroke="#030703" stroke-width="17" fill="none"/><ellipse cx="-16" cy="-8" rx="5" ry="2" fill="#cbd7ad"/><ellipse cx="16" cy="-8" rx="5" ry="2" fill="#cbd7ad"/></g>`;
    return `<g transform="translate(${x} ${y}) scale(${scale})" opacity=".97"><ellipse cx="0" cy="-207" rx="25" ry="35" fill="#030704"/><path d="M-26-174Q-56-155-60-100L-82-17l12 8 33-89-6 105h28l14-93 13 93h29l-7-104 30 87 12-7-22-88Q50-157 26-174z" fill="#020704"/><path d="m-16-210 7 1m20-1 7-1" stroke="#cad4b0" stroke-width="3" opacity=".85"/><path d="m-67-20-12 22m150-23 12 22" stroke="#020704" stroke-width="7"/></g>`;
  }
  const cameraScenes = [
    function (enemy) {
      // Loading bay.
      let s = `<rect width="1200" height="700" fill="#161e16"/><path d="M0 0h1200v408H0z" fill="url(#wall)"/><path d="M0 700h1200V408H0z" fill="url(#floor)"/><path d="m0 0 600 75L1200 0M0 100l600 30 600-30" stroke="#101810" stroke-width="22" fill="none"/><rect x="365" y="135" width="400" height="278" fill="#10170f" stroke="#4d5942" stroke-width="12"/>`;
      for (let i = 0; i < 14; i++)
        s += `<path d="M375 ${151 + i * 18}h380" stroke="${i % 2 ? "#283323" : "#37432e"}" stroke-width="9"/>`;
      s += `<rect x="90" y="48" width="44" height="536" fill="#202c20" stroke="#46543b" stroke-width="3"/><rect x="1000" y="35" width="55" height="590" fill="#1b261b" stroke="#46543b" stroke-width="3"/><path d="m80 550 64-13m-64-24 64-13m-64-24 64-13m854 122 67-16m-67-17 67-16m-67-17 67-16" stroke="#8f9160" stroke-width="12" opacity=".5"/><path d="m210 700 210-292m580 292L720 408m-720 89h1200M0 610h1200" stroke="#738064" stroke-width="1" opacity=".3"/><rect x="177" y="313" width="133" height="104" fill="#424d32" stroke="#6c7350"/><path d="M177 333h133m-108-20v104m85-104v104" stroke="#222f1d" stroke-width="9"/><rect x="211" y="257" width="98" height="57" fill="#50583d" stroke="#6f7651"/><rect x="864" y="342" width="110" height="76" fill="#293b29" stroke="#5c6c49"/><path d="M870 350h100v28H870z" fill="#18281a"/><rect x="431" y="102" width="265" height="6" fill="#dae3bc" opacity=".6"/><ellipse cx="559" cy="260" rx="290" ry="180" fill="url(#glow)"/><text x="565" y="80" text-anchor="middle" fill="#768566" font-size="17" font-family="monospace" letter-spacing="8">LOADING / 01</text><path d="M52 145v110h205m669-118h192v195" fill="none" stroke="#63724e" stroke-width="3"/><path d="M592 430q-140 78-35 129t-15 92" stroke="#9da582" stroke-width="2" fill="none" opacity=".16"/>`;
      if (enemy) s += figure(690, 421, 0.78);
      return s;
    },
    function (enemy) {
      // West hall.
      let s = `<rect width="1200" height="700" fill="#080f09"/><path d="M0 0 488 210v245L0 700z" fill="url(#side)"/><path d="m1200 0-512 210v245l512 245z" fill="#293727"/><path d="M0 0h1200L688 210H488z" fill="#172218"/><path d="M0 700h1200L688 455H488z" fill="url(#floor)"/><rect x="488" y="210" width="200" height="245" fill="#0d160e" stroke="#43523a" stroke-width="4"/><rect x="532" y="266" width="108" height="188" fill="#111f12"/><path d="M0 440 488 365m200 0 512 75M0 459l488-84m200 0 512 84" stroke="#647050" stroke-width="3"/>`;
      [
        [55, 96, 145, 500],
        [276, 183, 79, 309],
        [419, 235, 34, 233],
      ].forEach(([x, y, w, h]) => {
        s += `<path d="m${x} ${y} ${w} 58v${h}l-${w} 59z" fill="#0e190f" stroke="#4b5c3f" stroke-width="4"/><path d="m${x + w - 18} ${y + h * 0.55}v23" stroke="#899875" stroke-width="4"/>`;
      });
      s += `<path d="m1028 107-92 43v327l92 38z" fill="#203722" stroke="#506746" stroke-width="4"/><rect x="820" y="290" width="46" height="77" fill="#5a3d2e" stroke="#825844"/><text x="842" y="326" text-anchor="middle" font-size="12" fill="#c1a28a" font-family="monospace">FIRE</text><path d="M335 48h528l-69 25H403z" fill="#c5d5ac" opacity=".68"/><path d="M487 174h206l-25 9H512z" fill="#c5d5ac" opacity=".5"/><ellipse cx="600" cy="260" rx="380" ry="180" fill="url(#glow)"/><path d="m0 590 1200 0M280 700l254-245m370 245L644 455M600 700V455" stroke="#657658" stroke-width="1" opacity=".35"/><path d="m0 80 488 159m200 0 512-159" stroke="#030903" stroke-width="10"/><path d="m74 692 198-17 81 9-79 15" fill="#9bab80" opacity=".12"/>`;
      if (enemy) s += figure(596, 469, 0.84);
      return s;
    },
    function (enemy) {
      // Main corridor.
      let s = `<rect width="1200" height="700" fill="#18241a"/><path d="M0 0h1200v700H0z" fill="url(#wall)"/><path d="M0 520h1200v180H0z" fill="url(#floor)"/><rect x="310" y="104" width="372" height="421" fill="#0a130c" stroke="#4b5b40" stroke-width="16"/><path d="m320 114 133 115v187L320 515m350-401L543 229v187l127 99" fill="#293a28"/><rect x="453" y="228" width="90" height="188" fill="#0e1b10"/><path d="M453 255h90M454 263h88" stroke="#80916d" stroke-width="2"/><rect x="435" y="60" width="112" height="30" fill="#344e31" stroke="#758960"/><text x="491" y="80" fill="#c0d2a1" text-anchor="middle" font-family="monospace" font-size="15" letter-spacing="5">EXIT</text><path d="M112 0v520m-17-520v520" stroke="#5c6d4e" stroke-width="6"/><rect x="20" y="310" width="187" height="80" fill="#424e34" stroke="#6e7b55"/><text x="112" y="338" fill="#a8b58d" text-anchor="middle" font-family="monospace" font-size="12">SECTOR 04</text><text x="112" y="364" fill="#768665" text-anchor="middle" font-family="monospace" font-size="9">STAFF ONLY</text><path d="M760 250h440v270H760z" fill="#0e1b10"/><path d="M780 520V274h410" stroke="#4c6041" stroke-width="5" fill="none"/>`;
      for (let i = 0; i < 8; i++)
        s += `<path d="M${800 + i * 25} ${495 - i * 26}h${330 - i * 25}v26H${800 + i * 25}" fill="#2f402b" stroke="#647651" stroke-width="2"/>`;
      s += `<path d="m794 432 308-235" stroke="#82916a" stroke-width="5"/><path d="m815 426v-92m90 24v-94m92 23v-94" stroke="#526746" stroke-width="4"/><path d="M0 470h305m380 0h75" stroke="#697453" stroke-width="7"/><rect x="291" y="22" width="438" height="7" fill="#d8e2ba" opacity=".65"/><ellipse cx="500" cy="250" rx="360" ry="220" fill="url(#glow)"/><path d="M0 610h1200m-840 90 120-180m420 180L590 520" stroke="#738261" stroke-width="1" opacity=".3"/><path d="m129 496 47-14 8 25-40 12z" fill="#bdba95" opacity=".4"/>`;
      if (enemy) s += figure(497, 433, 0.69);
      return s;
    },
    function (enemy) {
      // Vent.
      let s = `<rect width="1200" height="700" fill="#111a12"/><path d="M0 0 455 258v181L0 700z" fill="#253324"/><path d="m1200 0-455 258v181l455 261z" fill="#1b2b1c"/><path d="M0 0h1200L745 258H455z" fill="#33402c"/><path d="M0 700h1200L745 439H455z" fill="#293b26"/>`;
      for (let i = 0; i < 9; i++) {
        const x = 50 + i * 48,
          y = 29 + i * 29;
        s += `<path d="M${x} ${y}H${1200 - x}V${700 - y}H${x}z" fill="none" stroke="${i % 2 ? "#637451" : "#0b140d"}" stroke-width="${i < 3 ? 8 : 4}" opacity=".75"/>`;
      }
      s += `<rect x="455" y="258" width="290" height="181" fill="#0a140c"/><circle cx="600" cy="347" r="80" fill="#132015" stroke="#6c7b59" stroke-width="5"/><circle cx="600" cy="347" r="68" fill="none" stroke="#31462d" stroke-width="3"/>`;
      for (let i = 0; i < 6; i++)
        s += `<path d="M600 347Q655 273 637 301L615 345z" fill="#546449" transform="rotate(${i * 60} 600 347)"/>`;
      s += `<circle cx="600" cy="347" r="16" fill="#1c2a1d" stroke="#75835e" stroke-width="3"/><path d="m0 656 1200 0M200 580h800M350 495h500" stroke="#192a19" stroke-width="3"/><path d="M32 61v550m1136-550v550" stroke="#9aa078" stroke-width="2" stroke-dasharray="2 20" opacity=".4"/><path d="m200 0 140 90-32 60 160 105" stroke="#697752" stroke-width="2" fill="none" opacity=".4"/><ellipse cx="600" cy="347" rx="240" ry="160" fill="url(#glow)"/><text x="44" y="652" fill="#82916b" font-size="18" font-family="monospace" letter-spacing="6">DUCT / B-04</text>`;
      if (enemy) s += figure(600, 360, 1.28, true);
      return s;
    },
    function (enemy, locked) {
      // Security door.
      let s = `<rect width="1200" height="700" fill="url(#wall)"/><path d="M0 600h1200v100H0z" fill="url(#floor)"/><path d="M0 0h140v700H0m1050-700h150v700h-150" fill="#142016"/><path d="M140 0v700m910-700v700" stroke="#506045" stroke-width="7"/><rect x="384" y="62" width="430" height="566" fill="#1e2d1f" stroke="#53654a" stroke-width="14"/><rect x="405" y="82" width="385" height="530" fill="#263526" stroke="#0d170e" stroke-width="5"/><rect x="523" y="134" width="152" height="220" fill="#151d12" stroke="#6c7651" stroke-width="7"/><rect x="532" y="144" width="134" height="201" fill="#7f795032"/><path d="M532 162h134m-134 35h134m-134 35h134m-134 35h134m-134 35h134M551 144v201m38-201v201m38-201v201" stroke="#0e1b0e" stroke-width="3"/><rect x="727" y="389" width="16" height="91" fill="#839276"/><path d="M735 429h-55" stroke="#96a086" stroke-width="9"/><text x="601" y="433" text-anchor="middle" fill="#8c9a7c" font-family="monospace" font-size="25" letter-spacing="7">04</text><text x="601" y="468" text-anchor="middle" fill="#798b6c" font-family="monospace" font-size="11" letter-spacing="3">SECURITY OFFICE</text><rect x="855" y="266" width="64" height="98" fill="#1a281b" stroke="#5c6a4d" stroke-width="2"/><circle cx="887" cy="283" r="5" fill="${locked ? "#b7c77b" : "#a8785b"}"/>`;
      for (let y = 0; y < 3; y++)
        for (let x = 0; x < 3; x++)
          s += `<rect x="${868 + x * 13}" y="${304 + y * 14}" width="7" height="7" fill="#596b4a"/>`;
      s += `<path d="M47 138h250v275h-65" stroke="#647451" stroke-width="4" fill="none"/><rect x="40" y="409" width="245" height="79" fill="#3d4c31" stroke="#687654"/><text x="160" y="441" text-anchor="middle" fill="#adb68e" font-size="12" font-family="monospace" letter-spacing="2">KEEP DOOR CLOSED</text><text x="160" y="466" text-anchor="middle" fill="#879972" font-size="10" font-family="monospace">AFTER MIDNIGHT</text><rect x="385" y="28" width="420" height="6" fill="#d5e0b7" opacity=".5"/><ellipse cx="600" cy="280" rx="360" ry="235" fill="url(#glow)"/><path d="M0 651h1200m-950 49 180-100m480 100L760 600" stroke="#6a7959" stroke-width="1" opacity=".4"/>`;
      if (enemy) s += figure(547, 635, 1.82);
      return s;
    },
  ];
  window.ShiftScenes = {
    render(index, enemy = false, locked = false) {
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${defs}${cameraScenes[index](enemy, locked)}<rect width="1200" height="700" filter="url(#rough)" opacity=".065" style="mix-blend-mode:soft-light"/><rect width="1200" height="700" fill="url(#vignette)"/></svg>`;
    },
    shadow: figure,
  };
})();
