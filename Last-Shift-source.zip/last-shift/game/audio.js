/* Original procedural audio: no recordings, streams, or external services. */
"use strict";
class ShiftAudio {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.enabled = true;
    this.ambient = null;
  }
  unlock() {
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.enabled ? 0.52 : 0;
        this.master.connect(this.ctx.destination);
      }
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
    } catch (_) {}
  }
  setEnabled(value) {
    this.enabled = value;
    if (this.ctx && this.master)
      this.master.gain.setTargetAtTime(
        value ? 0.52 : 0,
        this.ctx.currentTime,
        0.08,
      );
  }
  tone(freq, duration, volume = 0.1, type = "sine", delay = 0, endFreq = freq) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator(),
      gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.exponentialRampToValueAtTime(
      Math.max(10, endFreq),
      t + duration,
    );
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(volume, t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(t);
    osc.stop(t + duration + 0.02);
  }
  noise(duration = 0.16, volume = 0.055, frequency = 1600) {
    if (!this.ctx || !this.enabled) return;
    const length = Math.max(1, Math.floor(this.ctx.sampleRate * duration));
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate),
      data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++)
      data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    const source = this.ctx.createBufferSource(),
      filter = this.ctx.createBiquadFilter(),
      gain = this.ctx.createGain();
    source.buffer = buffer;
    filter.type = "bandpass";
    filter.frequency.value = frequency;
    filter.Q.value = 0.8;
    gain.gain.value = volume;
    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    source.start();
  }
  startAmbient() {
    this.unlock();
    if (!this.ctx || this.ambient) return;
    const osc = this.ctx.createOscillator(),
      gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 54;
    gain.gain.value = 0.032;
    osc.connect(gain);
    gain.connect(this.master);
    osc.start();
    const osc2 = this.ctx.createOscillator();
    osc2.type = "sine";
    osc2.frequency.value = 57;
    osc2.connect(gain);
    osc2.start();
    this.ambient = [osc, osc2, gain];
  }
  stopAmbient() {
    if (!this.ambient) return;
    try {
      this.ambient[0].stop();
      this.ambient[1].stop();
    } catch (_) {}
    this.ambient = null;
  }
  effect(name) {
    if (!this.enabled) return;
    if (name === "camera" || name === "monitor") {
      this.noise(0.18, 0.09, 2100);
      this.tone(820, 0.08, 0.035);
    } else if (name === "door") {
      this.noise(0.38, 0.18, 280);
      this.tone(85, 0.45, 0.16, "sine", 0, 30);
    } else if (name === "step") {
      this.tone(67, 0.25, 0.14, "sine");
      this.tone(53, 0.27, 0.12, "sine", 0.32);
    } else if (name === "vent") {
      this.noise(1.1, 0.13, 900);
      this.tone(178, 0.8, 0.045, "triangle", 0, 92);
    } else if (name === "alarm") {
      this.tone(580, 0.18, 0.085, "triangle");
      this.tone(440, 0.18, 0.07, "triangle", 0.25);
    } else if (name === "clear") {
      this.tone(460, 0.15, 0.07);
      this.tone(680, 0.25, 0.055, "sine", 0.12);
    } else if (name === "note") {
      this.noise(0.2, 0.045, 2500);
      this.tone(780, 0.18, 0.04);
    } else if (name === "loss") {
      this.noise(0.95, 0.23, 600);
      this.tone(110, 1.3, 0.19, "sawtooth", 0, 30);
    } else if (name === "win") {
      [330, 440, 554, 660].forEach((n, i) =>
        this.tone(n, 1.4, 0.055, "sine", i * 0.24),
      );
    }
  }
  suspend() {
    if (this.ctx && this.ctx.state === "running")
      this.ctx.suspend().catch(() => {});
  }
  resume() {
    if (this.ctx && this.enabled) this.ctx.resume().catch(() => {});
  }
}
window.ShiftAudio = ShiftAudio;
