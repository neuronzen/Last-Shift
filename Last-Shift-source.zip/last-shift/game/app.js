/* The Last Shift — offline UI, localization, input and persistence. */
"use strict";
(() => {
  const $ = (id) => document.getElementById(id);
  const icon = (name) =>
    `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const TEXT = {
    bn: {
      brandSub: "SECURITY SYSTEMS / EST. 1986",
      terminal: "TERMINAL 04 · DHAKA",
      genre: "AN OFFLINE SURVIVAL HORROR",
      tagline: "সকালটা দেখবে তো?",
      description:
        "পাঁচটি ক্যামেরা। একটি দরজা। সীমিত বিদ্যুৎ। পুরোনো কারখানায় আজ রাতে তুমি একা নও। সকাল ছয়টা পর্যন্ত টিকে থাকো।",
      start: "শিফট শুরু করো",
      manual: "গার্ডের নির্দেশিকা",
      nightOne: "প্রথম রাত",
      duration: "৪ মিনিটের শিফট",
      endings: "২টি সমাপ্তি",
      assignment: "ASSIGNMENT / 001",
      yourJob: "তোমার একটাই কাজ।",
      survive: "সকাল পর্যন্ত বেঁচে থাকো।",
      watch: "নজর রাখো",
      watchBrief: "ক্যামেরায় ছায়ার গতিবিধি দেখো।",
      listen: "শোনো",
      listenBrief: "দরজায় শব্দ? লক করো। ভেন্টে শব্দ? টর্চ ধরো।",
      conserve: "বিদ্যুৎ বাঁচাও",
      conserveBrief: "সব একসঙ্গে চালু রেখো না।",
      records: "আগের শিফটের রেকর্ড",
      headphones: "হেডফোনে আরও ভালো লাগবে",
      advisory: "হালকা ফ্লিকার ও আকস্মিক শব্দ · নির্দেশিকায় কমাতে পারো",
      sealed: "DOOR SEALED",
      powerOut: "বিদ্যুৎ শেষ।",
      stayQuiet: "নড়বে না। শব্দ করবে না।",
      inspect: "নথি পাওয়া গেছে · পড়ো",
      cameras: "ক্যামেরা",
      monitorClosed: "মনিটর খোলো",
      monitorOpen: "মনিটর বন্ধ করো",
      door: "দরজা",
      unlocked: "লক খোলা",
      locked: "লক করা",
      flashlight: "টর্চ",
      hold: "চেপে ধরে রাখো",
      untilDawn: "DAWN AT 06:00",
      power: "ব্যাকআপ বিদ্যুৎ",
      usage: "ব্যবহার",
      network: "ক্যামেরা নেটওয়ার্ক",
      you: "তুমি",
      sensors: "নিকটবর্তী সেন্সর",
      mainDoor: "মূল দরজা",
      vent: "ভেন্ট",
      clear: "পরিষ্কার",
      evidence: "নথি",
      office: "গার্ডের ঘর",
      footsteps: "পদশব্দ!",
      scraping: "ঘষার শব্দ!",
      clearing: "সরিয়ে দেওয়া হচ্ছে",
      officeHint: "ক্যামেরায় চোখ রাখো। দরজা আর ভেন্টের শব্দ খেয়াল করো।",
      camHint: "ক্যামেরায় দেখলে ছায়ার গতি কমে। কিন্তু বিদ্যুৎও খরচ হয়।",
      doorHint: "ও দরজার বাইরে। এখনই দরজা লক করো!",
      sealedHint: "দরজাটা লক রাখো। সেন্সর পরিষ্কার হলে খুলে দিও।",
      torchHint: "ভেন্টে কিছু আছে। টর্চ চেপে ধরে রাখো!",
      bothDanger: "দরজা লক করো + টর্চ চেপে ধরো!",
      doorDanger: "পদশব্দ দরজার বাইরে — দরজা লক করো",
      ventDanger: "ভেন্টে আঁচড়ের শব্দ — টর্চ ধরে রাখো",
      doorBlocked:
        "দরজা আটকে রেখেছে। সেন্সর পরিষ্কার হওয়া পর্যন্ত অপেক্ষা করো।",
      radioStart:
        "“গার্ড ০৪, ডিউটিতে স্বাগতম। ক্যামেরায় চোখ রাখবে। দরজাটা অকারণে বন্ধ রেখো না।”",
      radioIdle:
        "“ছায়া নজর এড়িয়ে এগোয়। ভেন্টের ফিসফিস শুধু টর্চে থামে। সকাল পর্যন্ত আর একটু…”",
      radioMoved: "ধীর পায়ের শব্দ। ক্যামেরায় কারও নড়াচড়া দেখা যাচ্ছে।",
      radioDoor: "“ও দরজার সামনে। লক করো, এখনই!”",
      radioVent: "ভেন্টে ধাতব ঘষার শব্দ। টর্চের আলো চেপে ধরে ওকে সরাও।",
      radioShadowClear: "পায়ের শব্দ সরে গেছে। দরজা খুলে বিদ্যুৎ বাঁচাতে পারো।",
      radioVentClear: "ভেন্ট আবার নীরব। টর্চ ছেড়ে দিতে পারো।",
      radioLow:
        "“বিদ্যুৎ এক-চতুর্থাংশ বাকি। দরজা আর মনিটর প্রয়োজন ছাড়া বন্ধ রাখো।”",
      radioCritical: "“ব্যাটারি প্রায় শেষ। একদম প্রয়োজন ছাড়া কিছু চালাবে না।”",
      radioOutage: "সব আলো নিভে গেল। দূরে কোথাও ভারী পায়ের শব্দ…",
      radioNote:
        "পুরোনো নথিটি সংগ্রহ করা হয়েছে। বাকি সত্যও কারখানার ভেতরেই আছে।",
      manualTitle: "রাতের ডিউটির নিয়ম",
      manualLead:
        "উজ্জ্বল টেক্সটাইলের পুরোনো ভবন। তুমি গার্ড ০৪। বাস্তবের ৪ মিনিটে রাত বারোটা থেকে সকাল ছয়টা—তার আগেই যেন কেউ ভেতরে না আসে।",
      manualCamera: "ছায়ার ওপর চোখ রাখো",
      manualCameraText:
        "ক্যামেরা খুলে ৫টি জায়গা দেখো। ছায়া ০১ → ০২ → ০৩ → ০৫ ধরে এগোয়। যে ক্যামেরায় ছায়া আছে, সেটিতে তাকালে ও ধীরে চলে।",
      manualDoor: "দরজা: শুধু বিপদের সময়",
      manualDoorText:
        "দরজার সেন্সরে পদশব্দ দেখলে লক করো। প্রায় ৩ সেকেন্ড পরে ছায়া সরে যাবে। সেন্সর পরিষ্কার হলে লক খুলে দাও—এতে বিদ্যুৎ বাঁচে।",
      manualTorch: "ভেন্টে টর্চের আলো",
      manualTorchText:
        "ভেন্টে ঘষার শব্দ শুনলে টর্চ বাটন প্রায় ৩ সেকেন্ড ধরে রাখো। টর্চ ধরলে মনিটর নিজে থেকেই নেমে যাবে। শুধু দরজা বন্ধ করলে ভেন্টের বিপদ যায় না।",
      manualPower: "বিদ্যুৎ ও পুরোনো নথি",
      manualPowerText:
        "দরজা, মনিটর ও টর্চ বিদ্যুৎ খরচ করে। ক্যামেরায় কখনও পুরোনো নথি পাওয়া যায়। তিনটি নথি সংগ্রহ করে বাঁচতে পারলে অন্য সমাপ্তি দেখবে।",
      reduceMotion: "ফ্লিকার ও অ্যানিমেশন কমাও",
      reduceMotionHelp: "স্থির ক্যামেরা ও কম ভিজুয়াল ইফেক্ট",
      soundSetting: "গেমের শব্দ",
      soundHelp: "শব্দ ছাড়াও সেন্সর ও সতর্কবার্তা দেখে খেলা যায়",
      gotIt: "বুঝেছি",
      back: "ফিরে যাও",
      resume: "শিফটে ফিরে যাও",
      paused: "শিফট থেমে আছে",
      pausedLead: "সময় ও বিদ্যুৎ—দুটোই থেমে আছে। তৈরি হলে ফিরে যাও।",
      abandon: "শিফট ছেড়ে দাও",
      abandonConfirm: "শিফট ছেড়ে যাবে?",
      abandonText: "এই শিফটের অগ্রগতি হারাবে। রেকর্ড আর সেটিংস থাকবে।",
      cancel: "না, খেলব",
      confirmAbandon: "হ্যাঁ, ছেড়ে দাও",
      recordsTitle: "ডিউটি রেজিস্টার",
      recordsLead:
        "রেকর্ড শুধু এই ডিভাইসে থাকে। কোনো অ্যাকাউন্ট বা ইন্টারনেট প্রয়োজন নেই।",
      attempts: "শিফট খেলেছ",
      wins: "বেঁচে ফিরেছ",
      best: "সর্বোচ্চ সময়",
      endingDawn: "সমাপ্তি ০১ · ভোরের আলো",
      endingArchive: "সমাপ্তি ০২ · হারানো নথি",
      undiscovered: "এখনও দেখা হয়নি",
      noteTitle: "পুরোনো নথি",
      collected: "নথি সংগ্রহ করা হয়েছে",
      continue: "ডিউটিতে ফেরো",
      retry: "আবার চেষ্টা করো",
      home: "মূল মেনু",
      shiftComplete: "SHIFT COMPLETE",
      noSignal: "SIGNAL LOST",
      dawnTitle: "YOU MADE IT.",
      archiveTitle: "THE TRUTH.",
      lostTitle: "NOT THIS TIME.",
      dawnStory:
        "সকাল ছয়টা। গেট খুলে গেছে। তুমি বেঁচে বেরিয়ে এসেছ। কিন্তু পেছনের ঘরে ফোনটা আবার বাজছে। কারখানার তিনটি পুরোনো নথি হয়তো বলে দেবে, কে তোমাকে ডেকেছিল।",
      archiveStory:
        "তিনটি নথি মিলিয়ে সত্যটা পরিষ্কার: সেই বন্ধ রাতে গার্ড ০৪ ভেন্টে আটকে পড়া কর্মীদের বাঁচাতে পারেনি। তুমি তালিকার নামগুলো বাইরে নিয়ে এসেছ। এবার সকাল সত্যিই হয়েছে। ফোন আর বাজে না।",
      shadowStory:
        "পায়ের শব্দ একসময় দরজার ঠিক বাইরে থেমেছিল। তুমি লক করার আগেই দরজাটা খুলে গেল। পরের বার দরজার সেন্সর দেখো—ও কাছে এলে লক করো।",
      whisperStory:
        "দরজা বন্ধ ছিল। কিন্তু ও দরজা দিয়ে আসেনি। ভেন্টের শব্দ শুনলে টর্চ প্রায় তিন সেকেন্ড চেপে ধরে রাখবে।",
      powerStory:
        "শেষ আলোটাও নিভে গেল। অন্ধকারে কিছু একটা তোমার নাম ধরে ডাকল। পরের বার অকারণে দরজা, মনিটর আর টর্চ চালু রেখো না।",
      survived: "ডিউটির সময়",
      powerLeft: "বিদ্যুৎ বাকি",
      notesFound: "নথি পেয়েছ",
      secretHint: "তিনটি নথি + সকাল পর্যন্ত টিকে থাকা = অন্য সমাপ্তি।",
      endingUnlocked: "নতুন সমাপ্তি রেজিস্টারে যোগ হয়েছে।",
      noFullscreen: "এই ব্রাউজারে ফুলস্ক্রিন চালু করা যাচ্ছে না।",
      noPower: "বিদ্যুৎ নেই। কোনো যন্ত্র কাজ করছে না।",
      exitTitle: "গেম বন্ধ করবে?",
      exitText: "তোমার রেকর্ড এই ফোনেই থেকে যাবে।",
      exit: "গেম বন্ধ করো",
      manualShortcut: "ডেস্কটপ কন্ট্রোল",
      soundOnLabel: "শব্দ বন্ধ করো",
      soundOffLabel: "শব্দ চালু করো",
      pauseLabel: "গেম থামাও",
      fullscreenLabel: "ফুলস্ক্রিন",
      languageLabel: "Switch to English",
      cameraNames: [
        "লোডিং বে",
        "পশ্চিম হল",
        "মূল করিডর",
        "ভেন্টিলেশন",
        "গার্ডের দরজা",
      ],
      notes: [
        {
          stamp: "INCIDENT LOG / 17.11.2006",
          body: "“রাত ০২:১৭। ভেন্টের ভেতর থেকে সাহায্যের ডাক আসছে। ম্যানেজার বলেছে দরজা খুলব না। কারখানার অর্ধেক বিদ্যুৎ বন্ধ। ক্যামেরায় কাউকে দেখা যাচ্ছে না। কিন্তু শব্দটা আছে।”",
          signature: "— রাতের গার্ড, আইডি ০৪",
        },
        {
          stamp: "MAINTENANCE MEMO / SECTOR 04",
          body: "“মূল দরজার চৌম্বক লক অতিরিক্ত বিদ্যুৎ টানে। ভেন্টের ছায়াগুলো সরাসরি আলো সহ্য করে না। যারা ক্যামেরায় দাঁড়িয়ে থাকে, তারা চায় কেউ তাদের দেখুক। চোখ সরালে এগোয়।”",
          signature: "— রক্ষণাবেক্ষণ বিভাগের শেষ নোট",
        },
        {
          stamp: "RECOVERED STAFF LIST / CONFIDENTIAL",
          body: "“সেই রাতে পাঁচজন ভেন্টে আটকা পড়েছিল। বের হওয়ার তালিকায় তাদের কারও নাম নেই। গার্ডের কাগজে একটাই লাইন বারবার লেখা—সকাল হলে এই নামগুলো বাইরে নিয়ে যেও।”",
          signature: "— ভাঁজ করা তালিকা: রফিক, সালমা, আজাদ, মিনা, হাশেম",
        },
      ],
    },
    en: {
      brandSub: "SECURITY SYSTEMS / EST. 1986",
      terminal: "TERMINAL 04 · DHAKA",
      genre: "AN OFFLINE SURVIVAL HORROR",
      tagline: "Will you see the morning?",
      description:
        "Five cameras. One door. A dying backup battery. You are not alone in this abandoned factory. Keep watch. Make it to 6 AM.",
      start: "Begin shift",
      manual: "Field manual",
      nightOne: "Night one",
      duration: "A 4-minute shift",
      endings: "2 endings",
      assignment: "ASSIGNMENT / 001",
      yourJob: "You have one job.",
      survive: "Survive until the morning.",
      watch: "Keep watch",
      watchBrief: "Follow the shadow across the cameras.",
      listen: "Listen closely",
      listenBrief: "Footsteps? Lock up. Scraping? Use your light.",
      conserve: "Conserve power",
      conserveBrief: "You cannot keep everything switched on.",
      records: "View the duty register",
      headphones: "Headphones recommended",
      advisory: "Mild flicker & sudden sounds · reduce effects in the manual",
      sealed: "DOOR SEALED",
      powerOut: "The power is gone.",
      stayQuiet: "Stay still. Stay quiet.",
      inspect: "Evidence found · inspect",
      cameras: "Cameras",
      monitorClosed: "Raise monitor",
      monitorOpen: "Lower monitor",
      door: "Security door",
      unlocked: "Unlocked",
      locked: "Locked",
      flashlight: "Flashlight",
      hold: "Press & hold",
      untilDawn: "DAWN AT 06:00",
      power: "Backup power",
      usage: "USAGE",
      network: "Camera network",
      you: "YOU",
      sensors: "Proximity sensors",
      mainDoor: "Main door",
      vent: "Ventilation",
      clear: "CLEAR",
      evidence: "Evidence",
      office: "Security office",
      footsteps: "FOOTSTEPS!",
      scraping: "SCRAPING!",
      clearing: "CLEARING",
      officeHint: "Watch the cameras. Listen to the door and the vent.",
      camHint: "Watching the shadow slows it down. But the monitor uses power.",
      doorHint: "Something is outside. Lock the door now!",
      sealedHint: "Keep it locked. Unlock when the door sensor clears.",
      torchHint: "Something in the vent. Press and hold your flashlight!",
      bothDanger: "LOCK THE DOOR + HOLD YOUR FLASHLIGHT!",
      doorDanger: "FOOTSTEPS OUTSIDE — LOCK THE DOOR",
      ventDanger: "SCRAPING IN THE VENT — HOLD YOUR FLASHLIGHT",
      doorBlocked: "Keep the door locked until the sensor clears.",
      radioStart:
        "“Guard 04, welcome to your shift. Watch the cameras. Don’t waste power on a locked door.”",
      radioIdle:
        "“The shadow moves when you look away. The whisper hates your light. Just hold on until morning…”",
      radioMoved: "Slow footsteps. Something has moved on the camera network.",
      radioDoor: "“It’s right outside. Lock the door. Now!”",
      radioVent:
        "Metal scraping inside the vent. Hold your flashlight to drive it away.",
      radioShadowClear:
        "The footsteps have faded. You can unlock the door to conserve power.",
      radioVentClear: "The vent is quiet again. You can release your light.",
      radioLow:
        "“A quarter of the battery left. Keep the door and monitor off unless you need them.”",
      radioCritical:
        "“The battery is almost dead. Only use what you absolutely need.”",
      radioOutage:
        "The lights go out. Somewhere nearby, heavy footsteps begin…",
      radioNote:
        "An old document recovered. The rest of the truth is still inside the factory.",
      manualTitle: "Rules for the night shift",
      manualLead:
        "Ujjal Textile, the old factory. You are Guard 04. Four real minutes take you from midnight to 6 AM. Don’t let anything inside.",
      manualCamera: "Keep an eye on the shadow",
      manualCameraText:
        "Raise the monitor to check five locations. The shadow follows 01 → 02 → 03 → 05. Watching its current camera slows its approach.",
      manualDoor: "Lock only when you need to",
      manualDoorText:
        "When the door sensor reports footsteps, lock it. The shadow retreats after about 3 seconds. Unlock once the sensor clears to save power.",
      manualTorch: "Light up the ventilation",
      manualTorchText:
        "When the vent sensor reports scraping, hold the flashlight for about 3 seconds. Using it lowers the monitor automatically. A locked door will not stop the vent threat.",
      manualPower: "Power and old documents",
      manualPowerText:
        "Your door, monitor and light drain the battery. Old documents appear on some cameras as the night progresses. Find all three and survive for an alternate ending.",
      reduceMotion: "Reduce flicker & animation",
      reduceMotionHelp: "Steadier cameras and fewer visual effects",
      soundSetting: "Game audio",
      soundHelp: "Sensors and on-screen cues make sound optional",
      gotIt: "Understood",
      back: "Go back",
      resume: "Resume shift",
      paused: "The night can wait.",
      pausedLead:
        "Time and power are paused. Take a breath. Return when you are ready.",
      abandon: "Abandon shift",
      abandonConfirm: "Leave your post?",
      abandonText:
        "This shift’s progress will be lost. Your records and settings will stay.",
      cancel: "Keep playing",
      confirmAbandon: "Leave shift",
      recordsTitle: "The duty register",
      recordsLead:
        "Saved only on this device. No account. No internet. No one else needs to know.",
      attempts: "Shifts started",
      wins: "Nights survived",
      best: "Best time",
      endingDawn: "Ending 01 · First light",
      endingArchive: "Ending 02 · The archive",
      undiscovered: "Not yet discovered",
      noteTitle: "Recovered document",
      collected: "Added to your evidence",
      continue: "Return to your post",
      retry: "Try again",
      home: "Main menu",
      shiftComplete: "SHIFT COMPLETE",
      noSignal: "SIGNAL LOST",
      dawnTitle: "YOU MADE IT.",
      archiveTitle: "THE TRUTH.",
      lostTitle: "NOT THIS TIME.",
      dawnStory:
        "6 AM. The gate opens. You walk out alive. Behind you, the office phone begins to ring again. Perhaps the factory’s three old documents explain who called you here.",
      archiveStory:
        "The three documents tell the truth. Guard 04 never rescued the workers trapped in the vent that night. You carry their names outside. This time, morning is real. The phone stays silent.",
      shadowStory:
        "The footsteps stopped just outside. Before you could lock it, the door opened. Next time, watch the door sensor. Lock up when something arrives.",
      whisperStory:
        "The door was locked. But it did not use the door. When you hear the vent scrape, hold your flashlight for about three seconds.",
      powerStory:
        "The last light went out. In the dark, something called your name. Next time, don’t leave your door, monitor and flashlight switched on.",
      survived: "Time survived",
      powerLeft: "Power left",
      notesFound: "Evidence",
      secretHint:
        "Recover three documents and survive to unlock the other ending.",
      endingUnlocked: "A new ending has been added to the duty register.",
      noFullscreen: "Fullscreen is not available in this browser.",
      noPower: "No power. None of the equipment responds.",
      exitTitle: "Clock out of the game?",
      exitText: "Your records will stay on this phone.",
      exit: "Close game",
      manualShortcut: "DESKTOP CONTROLS",
      soundOnLabel: "Mute sound",
      soundOffLabel: "Enable sound",
      pauseLabel: "Pause game",
      fullscreenLabel: "Fullscreen",
      languageLabel: "বাংলায় খেলো",
      cameraNames: [
        "Loading bay",
        "West hall",
        "Main corridor",
        "Ventilation",
        "Security door",
      ],
      notes: [
        {
          stamp: "INCIDENT LOG / 17.11.2006",
          body: "“02:17 AM. Calls for help from inside the ventilation. Management told me not to open the door. Half the power is gone. Nobody on the cameras. But I can still hear them.”",
          signature: "— Night guard, ID 04",
        },
        {
          stamp: "MAINTENANCE MEMO / SECTOR 04",
          body: "“The magnetic door lock draws excess power. The shapes in the ventilation cannot bear direct light. Those standing in front of the cameras want to be seen. Look away and they move.”",
          signature: "— The maintenance department’s last note",
        },
        {
          stamp: "RECOVERED STAFF LIST / CONFIDENTIAL",
          body: "“Five workers were trapped in the ventilation that night. None appear on the exit register. One line repeats on the guard’s papers: when morning comes, take these names outside.”",
          signature: "— Folded list: Rafiq, Salma, Azad, Mina, Hashem",
        },
      ],
    },
  };
  function readStore(key, fallback) {
    try {
      const value = JSON.parse(localStorage.getItem(key));
      return value && typeof value === "object" ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }
  function saveStore(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (_) {}
  }
  const savedSettings = readStore("lastshift.settings.v1", {});
  const settings = {
    lang: savedSettings.lang === "en" ? "en" : "bn",
    sound: savedSettings.sound !== false,
    reduced:
      savedSettings.reduced === true ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  };
  const savedRecords = readStore("lastshift.records.v1", {});
  const records = {
    attempts: Number(savedRecords.attempts) || 0,
    wins: Number(savedRecords.wins) || 0,
    best: Number(savedRecords.best) || 0,
    endings: Array.isArray(savedRecords.endings)
      ? savedRecords.endings.filter((x) => ["dawn", "archive"].includes(x))
      : [],
  };
  const t = (key) => TEXT[settings.lang][key] || key;
  const engine = new LastShiftCore.ShiftEngine();
  const audio = new ShiftAudio();
  audio.setEnabled(settings.sound);
  let modalKind = null,
    modalBuilder = null,
    pausedByModal = false,
    modalReturnToPause = false;
  let previousFocus = null,
    currentScene = "",
    activeRadio = "radioStart",
    lastRadioAt = 0,
    lastFrame = 0,
    lastRender = 0;
  let toastTimer,
    staticTimer,
    endSaved = false;
  const show = (element, visible) =>
    element.classList.toggle("hidden", !visible);
  const actionButton = (action, label, primary = false, symbol = null) =>
    `<button class="button ${primary ? "button-primary" : "button-outline"}" data-action="${action}">${symbol ? icon(symbol) : ""}<span>${t(label)}</span></button>`;
  function persistSettings() {
    saveStore("lastshift.settings.v1", settings);
  }
  function toast(text) {
    $("toast").textContent = text;
    show($("toast"), true);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => show($("toast"), false), 3000);
  }
  function setRadio(key) {
    activeRadio = key;
    lastRadioAt = engine.state.elapsed;
    $("radio-text").textContent = t(key);
  }
  function clockFromSeconds(seconds) {
    const mins = Math.min(360, Math.floor((seconds / engine.duration) * 360));
    return `${String(Math.floor(mins / 60)).padStart(2, "0")}:${String(mins % 60).padStart(2, "0")}`;
  }
  function applyLanguage() {
    document.documentElement.lang = settings.lang;
    document.querySelectorAll("[data-t]").forEach((el) => {
      el.textContent = t(el.dataset.t);
    });
    $("language").textContent = settings.lang === "bn" ? "EN" : "বাংলা";
    $("language").setAttribute("aria-label", t("languageLabel"));
    $("pause-button").setAttribute("aria-label", t("pauseLabel"));
    $("fullscreen").setAttribute("aria-label", t("fullscreenLabel"));
    $("radio-text").textContent = t(activeRadio);
    if (["running", "paused"].includes(engine.state.status))
      $("top-label").textContent = "GUARD 04 · ON DUTY";
    $("camera-list").innerHTML = t("cameraNames")
      .map(
        (name, i) =>
          `<button data-camera="${i}" aria-label="${name}"><span>CAM ${String(i + 1).padStart(2, "0")}</span><span>${name}</span><i></i></button>`,
      )
      .join("");
    document
      .querySelectorAll("[data-camera]")
      .forEach((el) =>
        el.setAttribute(
          "aria-label",
          t("cameraNames")[Number(el.dataset.camera)],
        ),
      );
    document.body.classList.toggle("reduced-motion", settings.reduced);
    updateSoundButton();
    if (modalKind && modalBuilder) renderModal();
    if (
      ["won", "lost"].includes(engine.state.status) &&
      !$("end-screen").classList.contains("hidden")
    )
      renderEndScreen();
    currentScene = "";
    renderGame();
  }
  function updateSoundButton() {
    $("sound").innerHTML = icon(settings.sound ? "sound" : "mute");
    $("sound").setAttribute(
      "aria-label",
      t(settings.sound ? "soundOnLabel" : "soundOffLabel"),
    );
    $("sound").setAttribute("aria-pressed", String(settings.sound));
  }
  function renderModal() {
    $("modal-content").innerHTML = modalBuilder();
    $("modal-close").setAttribute("aria-label", t("back"));
  }
  function openModal(kind, builder, returnToPause = false) {
    if (!modalKind) {
      previousFocus = document.activeElement;
      pausedByModal = engine.pause();
    }
    modalKind = kind;
    modalBuilder = builder;
    modalReturnToPause = returnToPause;
    if (engine.state.status === "paused") audio.suspend();
    renderModal();
    show($("modal-backdrop"), true);
    $("modal").focus({ preventScroll: true });
  }
  function hideModal(resume = true) {
    if (modalReturnToPause && resume) {
      showPause();
      return;
    }
    show($("modal-backdrop"), false);
    modalKind = null;
    modalBuilder = null;
    modalReturnToPause = false;
    if (resume && pausedByModal) {
      engine.resume();
      audio.resume();
    }
    pausedByModal = false;
    if (previousFocus && document.contains(previousFocus))
      previousFocus.focus({ preventScroll: true });
    renderGame();
  }
  function settingsMarkup() {
    return `<div class="setting-row"><div>${t("soundSetting")}<small>${t("soundHelp")}</small></div><button class="switch" role="switch" aria-label="${t("soundSetting")}" aria-checked="${settings.sound}" data-setting="sound"></button></div><div class="setting-row"><div>${t("reduceMotion")}<small>${t("reduceMotionHelp")}</small></div><button class="switch" role="switch" aria-label="${t("reduceMotion")}" aria-checked="${settings.reduced}" data-setting="reduced"></button></div>`;
  }
  function showManual(fromPause = false) {
    openModal(
      "manual",
      () =>
        `<div class="modal-eyebrow">NIGHTWATCH / FIELD MANUAL</div><h2 id="modal-title">${t("manualTitle")}</h2><p class="lead">${t("manualLead")}</p><div class="manual-grid">${[
          ["camera", "manualCamera", "manualCameraText"],
          ["lock", "manualDoor", "manualDoorText"],
          ["light", "manualTorch", "manualTorchText"],
          ["note", "manualPower", "manualPowerText"],
        ]
          .map(
            ([i, a, b]) =>
              `<div class="manual-card">${icon(i)}<strong>${t(a)}</strong><p>${t(b)}</p></div>`,
          )
          .join(
            "",
          )}</div><div class="keyboard-help"><span><kbd>C</kbd>${t("cameras")}</span><span><kbd>E</kbd>${t("door")}</span><span><kbd>SPACE</kbd>${t("flashlight")}</span><span><kbd>ESC</kbd>${t("paused")}</span></div>${settingsMarkup()}<div class="modal-actions">${actionButton("close-modal", fromPause ? "back" : "gotIt", true, "check")}</div>`,
      fromPause,
    );
  }
  function showPause() {
    modalReturnToPause = false;
    openModal(
      "pause",
      () =>
        `<div class="modal-eyebrow">TERMINAL 04 / PAUSED</div><h2 id="modal-title">${t("paused")}</h2><p class="lead">${t("pausedLead")}</p><div class="records-grid"><div class="record-card"><b>${engine.clock}</b><span>${t("survived")}</span></div><div class="record-card"><b>${Math.ceil(engine.state.power)}%</b><span>${t("powerLeft")}</span></div><div class="record-card"><b>${engine.state.notes.length}/3</b><span>${t("notesFound")}</span></div></div>${settingsMarkup()}<div class="modal-actions">${actionButton("close-modal", "resume", true, "play")}${actionButton("pause-manual", "manual", false, "book")}</div><div class="modal-actions">${actionButton("ask-abandon", "abandon", false)}</div>`,
    );
  }
  function showRecords() {
    openModal(
      "records",
      () =>
        `<div class="modal-eyebrow">PERSONNEL / GUARD 04</div><h2 id="modal-title">${t("recordsTitle")}</h2><p class="lead">${t("recordsLead")}</p><div class="records-grid"><div class="record-card"><b>${records.attempts}</b><span>${t("attempts")}</span></div><div class="record-card"><b>${records.wins}</b><span>${t("wins")}</span></div><div class="record-card"><b>${clockFromSeconds(records.best)}</b><span>${t("best")}</span></div></div><div class="ending-list">${["dawn", "archive"].map((e) => `<div class="${records.endings.includes(e) ? "" : "unseen"}">${icon(records.endings.includes(e) ? "check" : "lock")}<span>${t(e === "dawn" ? "endingDawn" : "endingArchive")}${records.endings.includes(e) ? "" : `<br><small>${t("undiscovered")}</small>`}</span></div>`).join("")}</div><div class="modal-actions">${actionButton("close-modal", "back", true)}</div>`,
    );
  }
  function showNote(id) {
    openModal("note", () => {
      const note = t("notes")[id];
      return `<div class="modal-eyebrow">ARCHIVE / DOCUMENT ${String(id + 1).padStart(2, "0")}</div><h2 id="modal-title">${t("noteTitle")}</h2><p class="lead">${t("collected")} · ${engine.state.notes.length}/3</p><div class="note-paper"><div class="note-stamp">${note.stamp}</div><p>${note.body}</p><p class="note-signature">${note.signature}</p></div><div class="modal-actions">${actionButton("close-modal", "continue", true, "arrow")}</div>`;
    });
  }
  function askAbandon() {
    openModal(
      "abandon",
      () =>
        `<div class="modal-eyebrow">END THIS SHIFT?</div><h2 id="modal-title">${t("abandonConfirm")}</h2><p class="lead">${t("abandonText")}</p><div class="modal-actions">${actionButton("return-pause", "cancel", true)}${actionButton("home", "confirmAbandon")}</div>`,
      true,
    );
  }
  function startShift() {
    hideModal(false);
    show($("menu-screen"), false);
    show($("end-screen"), false);
    show($("game-screen"), true);
    show($("pause-button"), true);
    $("top-label").textContent = "GUARD 04 · ON DUTY";
    records.attempts += 1;
    saveStore("lastshift.records.v1", records);
    engine.start();
    endSaved = false;
    currentScene = "";
    lastFrame = performance.now();
    audio.unlock();
    audio.startAmbient();
    setRadio("radioStart");
    processEvents();
    renderGame();
    window.scrollTo(0, 0);
  }
  function goHome() {
    records.best = Math.max(records.best, engine.state.elapsed);
    saveStore("lastshift.records.v1", records);
    hideModal(false);
    audio.stopAmbient();
    engine.reset();
    engine.drainEvents();
    show($("game-screen"), false);
    show($("end-screen"), false);
    show($("menu-screen"), true);
    show($("pause-button"), false);
    $("top-label").textContent = t("terminal");
    currentScene = "";
    window.scrollTo(0, 0);
  }
  function saveEnd() {
    if (endSaved) return;
    endSaved = true;
    records.best = Math.max(records.best, engine.state.elapsed);
    if (engine.state.status === "won") {
      records.wins += 1;
      if (!records.endings.includes(engine.state.ending))
        records.endings.push(engine.state.ending);
    }
    saveStore("lastshift.records.v1", records);
  }
  function renderEndScreen() {
    const s = engine.state,
      won = s.status === "won",
      archive = s.ending === "archive";
    const story = won
      ? archive
        ? "archiveStory"
        : "dawnStory"
      : s.cause === "shadow"
        ? "shadowStory"
        : s.cause === "whisper"
          ? "whisperStory"
          : "powerStory";
    $("end-screen").classList.toggle("lost", !won);
    $("end-screen").innerHTML =
      `<div class="end-content"><div class="end-eyebrow"><span class="status-dot ${won ? "amber" : ""}"></span>${t(won ? "shiftComplete" : "noSignal")} / ${won ? "06:00 AM" : engine.clock + " AM"}</div><div class="end-icon">${icon(won ? (archive ? "note" : "check") : "eye")}</div><h2 class="end-title">${t(won ? (archive ? "archiveTitle" : "dawnTitle") : "lostTitle")}</h2><p class="end-story">${t(story)}</p><div class="end-stats"><div><b>${engine.clock}</b><span>${t("survived")}</span></div><div><b>${Math.ceil(s.power)}%</b><span>${t("powerLeft")}</span></div><div><b>${s.notes.length} / 3</b><span>${t("notesFound")}</span></div></div><div class="end-actions">${actionButton("start", "retry", true, "arrow")}${actionButton("home", "home", false)}</div><p class="end-hint">${t(won && archive ? "endingUnlocked" : "secretHint")}</p></div>`;
    show($("end-screen"), true);
    show($("pause-button"), false);
    $("top-label").textContent = won
      ? "SHIFT COMPLETE · 06:00"
      : "TERMINAL 04 · OFFLINE";
  }
  function finishGame() {
    saveEnd();
    audio.stopAmbient();
    audio.effect(engine.state.status === "won" ? "win" : "loss");
    renderEndScreen();
    $("end-screen").querySelector("button").focus({ preventScroll: true });
  }
  function processEvents() {
    engine.drainEvents().forEach((e) => {
      if (e.type === "camera" || e.type === "monitor") {
        audio.effect(e.type);
        currentScene = "";
        if (e.type === "camera" || e.open) {
          show($("camera-static"), true);
          clearTimeout(staticTimer);
          staticTimer = setTimeout(
            () => show($("camera-static"), false),
            settings.reduced ? 50 : 160,
          );
        }
      } else if (e.type === "door") {
        audio.effect("door");
      } else if (e.type === "shadowMoved") {
        audio.effect("step");
        setRadio("radioMoved");
      } else if (e.type === "doorDanger") {
        audio.effect("alarm");
        audio.effect("step");
        setRadio("radioDoor");
      } else if (e.type === "ventDanger") {
        audio.effect("vent");
        setRadio("radioVent");
      } else if (e.type === "shadowRepelled") {
        audio.effect("clear");
        setRadio("radioShadowClear");
      } else if (e.type === "whisperRepelled") {
        audio.effect("clear");
        setRadio("radioVentClear");
      } else if (e.type === "lowPower") {
        audio.effect("alarm");
        setRadio("radioLow");
      } else if (e.type === "criticalPower") {
        audio.effect("alarm");
        setRadio("radioCritical");
      } else if (e.type === "outage") {
        audio.effect("door");
        setRadio("radioOutage");
      } else if (e.type === "note") {
        audio.effect("note");
        setRadio("radioNote");
        showNote(e.id);
      } else if (e.type === "won" || e.type === "lost") {
        finishGame();
      }
    });
  }
  function renderGame() {
    const s = engine.state;
    $("clock").innerHTML = `${engine.clock}<span>AM</span>`;
    $("night-progress").style.width = `${(s.elapsed / engine.duration) * 100}%`;
    $("power-value").innerHTML = `${Math.ceil(s.power)}<span>%</span>`;
    $("power-bar").style.width = `${s.power}%`;
    document
      .querySelector(".power-panel")
      .classList.toggle("low", s.power <= 25);
    document.querySelectorAll("#usage-bars i").forEach((el, i) => {
      el.classList.toggle("on", i < engine.usage);
      el.classList.toggle("high", engine.usage >= 4);
    });
    $("monitor-button").classList.toggle("active", s.monitor);
    $("monitor-button").setAttribute("aria-pressed", String(s.monitor));
    $("monitor-state").textContent = t(
      s.monitor ? "monitorOpen" : "monitorClosed",
    );
    $("door-button").classList.toggle("active", s.door);
    $("door-button").setAttribute("aria-pressed", String(s.door));
    $("door-button").classList.toggle(
      "danger",
      s.shadow.stage === 3 && !s.door && !s.outage,
    );
    $("door-button").classList.toggle(
      "pulse-warning",
      s.shadow.stage === 3 && !s.door && !s.outage,
    );
    $("door-button").querySelector(".control-icon").innerHTML = icon(
      s.door ? "lock" : "unlock",
    );
    $("door-state").textContent = t(s.door ? "locked" : "unlocked");
    $("flashlight-button").classList.toggle("active", s.flashlight);
    $("flashlight-button").classList.toggle(
      "danger",
      s.whisper.active && !s.outage,
    );
    $("flashlight-button").setAttribute("aria-pressed", String(s.flashlight));
    ["monitor-button", "door-button", "flashlight-button"].forEach((id) => {
      $(id).disabled = s.outage;
    });
    show($("office-view"), !s.monitor);
    show($("camera-view"), s.monitor);
    show($("outage-overlay"), s.outage);
    show($("flashlight-beam"), s.flashlight);
    show($("door-lock-overlay"), s.door && !s.monitor && !s.outage);
    show($("door-shadow"), s.shadow.stage === 3 && !s.outage);
    show($("vent-eyes"), s.whisper.active && !s.outage);
    $("office-view").classList.toggle("torch", s.flashlight);
    $("office-view").classList.toggle("powerless", s.outage);
    $("view-name").textContent = s.monitor
      ? t("cameraNames")[s.camera].toUpperCase()
      : t("office").toUpperCase();
    $("view-code").textContent = s.monitor
      ? `CAM ${String(s.camera + 1).padStart(2, "0")} / LIVE`
      : "STATION / 04";
    $("camera-name").textContent =
      `CAM ${String(s.camera + 1).padStart(2, "0")}`;
    $("camera-timestamp").textContent =
      engine.clock +
      ":" +
      String(Math.floor((s.elapsed * 1.5) % 60)).padStart(2, "0");
    const shadowCam = LastShiftCore.SHADOW_CAMERAS[s.shadow.stage];
    const enemy =
      (s.camera === 3 && s.whisper.active) ||
      (s.shadow.stage >= 0 && s.camera === shadowCam);
    const sceneKey = `${s.camera}:${enemy}:${s.door}`;
    if (s.monitor && sceneKey !== currentScene) {
      $("camera-scene").innerHTML = ShiftScenes.render(s.camera, enemy, s.door);
      currentScene = sceneKey;
    }
    $("signal-label").textContent = enemy ? "SIGNAL 74%" : "SIGNAL 98%";
    document.querySelectorAll("[data-camera]").forEach((el) => {
      const selected = s.monitor && Number(el.dataset.camera) === s.camera;
      el.classList.toggle("selected", selected);
      el.setAttribute("aria-pressed", String(selected));
      el.disabled = s.outage;
    });
    document
      .querySelector(".camera-panel")
      .classList.toggle("standby", !s.monitor);
    $("network-state").textContent = s.monitor ? "ONLINE" : "STANDBY";
    $("network-state").classList.toggle("active", s.monitor);
    const doorThreat = s.shadow.stage === 3 && !s.outage,
      ventThreat = s.whisper.active && !s.outage;
    $("door-sensor").classList.toggle("alert", doorThreat);
    $("door-sensor").classList.toggle("locked", s.door && !doorThreat);
    $("door-sensor").querySelector("b").textContent = t(
      doorThreat ? "footsteps" : s.door ? "locked" : "clear",
    );
    $("vent-sensor").classList.toggle("alert", ventThreat);
    $("vent-sensor").querySelector("b").textContent = ventThreat
      ? s.flashlight
        ? `${t("clearing")} ${Math.min(100, Math.round((s.whisper.repel / 2.2) * 100))}%`
        : t("scraping")
      : t("clear");
    show($("danger-strip"), doorThreat || ventThreat);
    $("danger-strip").textContent = t(
      doorThreat && ventThreat && !s.door
        ? "bothDanger"
        : ventThreat
          ? "ventDanger"
          : s.door
            ? "doorBlocked"
            : "doorDanger",
    );
    $("view-hint").textContent = t(
      s.monitor
        ? "camHint"
        : ventThreat
          ? "torchHint"
          : doorThreat
            ? s.door
              ? "sealedHint"
              : "doorHint"
            : "officeHint",
    );
    show($("view-hint"), !s.outage && !s.monitor);
    show($("note-button"), engine.availableNote() >= 0);
    $("note-count").textContent = `${s.notes.length} / 3`;
    document
      .querySelectorAll(".evidence-dots i")
      .forEach((el, i) => el.classList.toggle("found", s.notes.includes(i)));
    if (
      s.status === "running" &&
      s.elapsed - lastRadioAt > 17 &&
      !doorThreat &&
      !ventThreat &&
      !s.outage
    )
      setRadio("radioIdle");
  }
  function useAction(action) {
    audio.unlock();
    if (action === "start") startShift();
    else if (action === "home") goHome();
    else if (action === "close-modal") hideModal();
    else if (action === "pause-manual") showManual(true);
    else if (action === "return-pause") showPause();
    else if (action === "ask-abandon") askAbandon();
    else if (action === "exit" && window.AndroidBridge)
      window.AndroidBridge.closeGame();
  }
  $("start-button").addEventListener("click", () => useAction("start"));
  $("manual-button").addEventListener("click", () => showManual(false));
  $("records-button").addEventListener("click", showRecords);
  $("brand").addEventListener("click", () => {
    if (engine.state.status === "running") showPause();
    else if (engine.state.status !== "paused") goHome();
  });
  $("pause-button").addEventListener("click", showPause);
  $("language").addEventListener("click", () => {
    settings.lang = settings.lang === "bn" ? "en" : "bn";
    persistSettings();
    applyLanguage();
  });
  $("sound").addEventListener("click", () => {
    settings.sound = !settings.sound;
    audio.unlock();
    audio.setEnabled(settings.sound);
    persistSettings();
    updateSoundButton();
  });
  $("fullscreen").addEventListener("click", async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (document.documentElement.requestFullscreen)
        await document.documentElement.requestFullscreen();
      else toast(t("noFullscreen"));
    } catch (_) {
      toast(t("noFullscreen"));
    }
  });
  $("modal-close").addEventListener("click", () => hideModal());
  $("modal-backdrop").addEventListener("click", (e) => {
    if (e.target === $("modal-backdrop") && modalKind !== "note") hideModal();
  });
  $("modal-content").addEventListener("click", (e) => {
    const setting = e.target.closest("[data-setting]");
    if (setting) {
      const key = setting.dataset.setting;
      settings[key] = !settings[key];
      if (key === "sound") {
        audio.setEnabled(settings.sound);
        audio.unlock();
      }
      persistSettings();
      document.body.classList.toggle("reduced-motion", settings.reduced);
      updateSoundButton();
      setting.setAttribute("aria-checked", String(settings[key]));
      if (engine.state.status === "paused") audio.suspend();
      return;
    }
    const action = e.target.closest("[data-action]");
    if (action) useAction(action.dataset.action);
  });
  $("end-screen").addEventListener("click", (e) => {
    const action = e.target.closest("[data-action]");
    if (action) useAction(action.dataset.action);
  });
  function guarded(action) {
    if (engine.state.outage) {
      toast(t("noPower"));
      return;
    }
    audio.unlock();
    action();
    processEvents();
    renderGame();
  }
  $("monitor-button").addEventListener("click", () =>
    guarded(() => engine.toggleMonitor()),
  );
  $("door-button").addEventListener("click", () =>
    guarded(() => engine.toggleDoor()),
  );
  $("game-screen").addEventListener("click", (e) => {
    const target = e.target.closest("[data-camera]");
    if (!target) return;
    guarded(() => {
      if (engine.state.status !== "running") return;
      if (!engine.state.monitor) engine.toggleMonitor();
      engine.selectCamera(Number(target.dataset.camera));
    });
  });
  $("note-button").addEventListener("click", () => {
    engine.collectNote();
    processEvents();
    renderGame();
  });
  const flashlight = $("flashlight-button");
  flashlight.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    try {
      flashlight.setPointerCapture(e.pointerId);
    } catch (_) {}
    guarded(() => engine.setFlashlight(true));
  });
  function releaseLight() {
    engine.setFlashlight(false);
    renderGame();
  }
  flashlight.addEventListener("pointerup", releaseLight);
  flashlight.addEventListener("pointercancel", releaseLight);
  flashlight.addEventListener("lostpointercapture", releaseLight);
  flashlight.addEventListener("contextmenu", (e) => e.preventDefault());
  document.addEventListener("pointerup", () => {
    if (engine.state.flashlight) releaseLight();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Tab" && modalKind) {
      const focusables = $("modal").querySelectorAll(
        'button:not(:disabled),[tabindex="0"]',
      );
      if (!focusables.length) return;
      const first = focusables[0],
        last = focusables[focusables.length - 1];
      if (
        e.shiftKey &&
        (document.activeElement === first ||
          document.activeElement === $("modal"))
      ) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
      return;
    }
    if (e.key === "Escape") {
      e.preventDefault();
      if (modalKind) hideModal();
      else if (engine.state.status === "running") showPause();
      else if (["lost", "won"].includes(engine.state.status)) goHome();
      return;
    }
    if (modalKind || engine.state.status !== "running") return;
    if (e.code === "Space") {
      e.preventDefault();
      if (!e.repeat) guarded(() => engine.setFlashlight(true));
      return;
    }
    if (e.repeat) return;
    if (e.code === "KeyC") {
      e.preventDefault();
      guarded(() => engine.toggleMonitor());
    } else if (e.code === "KeyE") {
      e.preventDefault();
      guarded(() => engine.toggleDoor());
    } else if (/^[1-5]$/.test(e.key)) {
      e.preventDefault();
      guarded(() => {
        if (!engine.state.monitor) engine.toggleMonitor();
        engine.selectCamera(Number(e.key) - 1);
      });
    }
  });
  document.addEventListener("keyup", (e) => {
    if (e.code === "Space") releaseLight();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      engine.setFlashlight(false);
      if (engine.state.status === "running") showPause();
      audio.suspend();
    }
  });
  window.onNativePause = () => {
    engine.setFlashlight(false);
    if (engine.state.status === "running") showPause();
    audio.suspend();
  };
  window.onNativeBack = () => {
    if (modalKind) {
      hideModal();
      return;
    }
    if (engine.state.status === "running") {
      showPause();
      return;
    }
    if (["won", "lost"].includes(engine.state.status)) {
      goHome();
      return;
    }
    openModal(
      "exit",
      () =>
        `<div class="modal-eyebrow">NIGHTWATCH / CLOCK OUT</div><h2 id="modal-title">${t("exitTitle")}</h2><p class="lead">${t("exitText")}</p><div class="modal-actions">${actionButton("close-modal", "back", true)}${actionButton("exit", "exit")}</div>`,
    );
  };
  function frame(now) {
    const dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.15) : 0;
    lastFrame = now;
    if (engine.state.status === "running") {
      engine.tick(dt);
      processEvents();
    }
    if (
      now - lastRender >= 100 &&
      ["running", "paused"].includes(engine.state.status)
    ) {
      renderGame();
      lastRender = now;
    }
    requestAnimationFrame(frame);
  }
  applyLanguage();
  if (window.AndroidBridge) show($("fullscreen"), false);
  requestAnimationFrame(frame);
  window.LastShift = {
    engine,
    start: startShift,
    pause: showPause,
    home: goHome,
    snapshot: () => JSON.parse(JSON.stringify(engine.state)),
    settings,
    records,
  };
})();
