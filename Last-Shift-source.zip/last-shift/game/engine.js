/* Last Shift — deterministic, DOM-independent game rules. */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.LastShiftCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const CAMERA_NAMES = [
    "Loading bay",
    "West hall",
    "Main corridor",
    "Ventilation",
    "Security door",
  ];
  const SHADOW_CAMERAS = [0, 1, 2, 4];
  const NOTE_TIMES = [16, 74, 132];
  const NOTE_CAMERAS = [0, 2, 3];

  class ShiftEngine {
    constructor(options = {}) {
      this.random = options.random || Math.random;
      this.duration = options.duration || 240;
      this.events = [];
      this.reset();
    }
    reset() {
      this.events = [];
      this.state = {
        status: "ready",
        elapsed: 0,
        power: 100,
        monitor: false,
        door: false,
        flashlight: false,
        camera: 0,
        outage: false,
        outageTimer: 16,
        shadow: { stage: -1, timer: 17, attack: 8.5, repel: 0 },
        whisper: { active: false, timer: 57, attack: 14, repel: 0 },
        notes: [],
        lowWarning: false,
        criticalWarning: false,
        cause: null,
        ending: null,
        doorRepels: 0,
        ventRepels: 0,
      };
      return this.state;
    }
    start() {
      this.reset();
      this.state.status = "running";
      this.emit("started");
      return this.state;
    }
    emit(type, detail = {}) {
      this.events.push({ type, ...detail });
    }
    drainEvents() {
      return this.events.splice(0);
    }
    between(a, b) {
      return a + this.random() * (b - a);
    }
    get hour() {
      return Math.min(6, Math.floor((this.state.elapsed / this.duration) * 6));
    }
    get clock() {
      const minutes = Math.min(
        360,
        Math.floor((this.state.elapsed / this.duration) * 360),
      );
      return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
    }
    get usage() {
      const s = this.state;
      if (s.outage) return 0;
      return (
        1 + Number(s.monitor) + 2 * Number(s.door) + 2 * Number(s.flashlight)
      );
    }
    pause() {
      if (this.state.status !== "running") return false;
      this.state.status = "paused";
      this.state.flashlight = false;
      return true;
    }
    resume() {
      if (this.state.status !== "paused") return false;
      this.state.status = "running";
      return true;
    }
    toggleMonitor() {
      const s = this.state;
      if (s.status !== "running" || s.outage) return false;
      s.monitor = !s.monitor;
      s.flashlight = false;
      this.emit("monitor", { open: s.monitor });
      return true;
    }
    selectCamera(index) {
      const s = this.state;
      if (
        s.status !== "running" ||
        s.outage ||
        !s.monitor ||
        index < 0 ||
        index > 4 ||
        !Number.isInteger(index)
      )
        return false;
      if (s.camera !== index) {
        s.camera = index;
        this.emit("camera", { index });
      }
      return true;
    }
    toggleDoor() {
      const s = this.state;
      if (s.status !== "running" || s.outage) return false;
      s.door = !s.door;
      this.emit("door", { closed: s.door });
      return true;
    }
    setFlashlight(on) {
      const s = this.state;
      if (!on) {
        s.flashlight = false;
        return true;
      }
      if (s.status !== "running" || s.outage) return false;
      if (s.monitor) {
        s.monitor = false;
        this.emit("monitor", { open: false });
      }
      s.flashlight = true;
      return true;
    }
    availableNote() {
      const s = this.state;
      if (!s.monitor || s.outage) return -1;
      return NOTE_CAMERAS.findIndex(
        (cam, i) =>
          cam === s.camera &&
          s.elapsed >= NOTE_TIMES[i] &&
          !s.notes.includes(i),
      );
    }
    collectNote() {
      if (this.state.status !== "running") return -1;
      const id = this.availableNote();
      if (id < 0) return -1;
      this.state.notes.push(id);
      this.emit("note", { id });
      return id;
    }
    lose(cause) {
      const s = this.state;
      s.status = "lost";
      s.cause = cause;
      s.flashlight = false;
      this.emit("lost", { cause });
    }
    tick(delta) {
      const s = this.state;
      if (s.status !== "running" || !Number.isFinite(delta) || delta <= 0)
        return;
      // Fixed small substeps keep outcomes independent of render rate.
      let remaining = delta;
      while (remaining > 0 && s.status === "running") {
        const dt = Math.min(0.1, remaining);
        remaining -= dt;
        this.step(dt);
      }
    }
    step(dt) {
      const s = this.state;
      s.elapsed = Math.min(this.duration, s.elapsed + dt);
      if (s.elapsed >= this.duration - 0.000001) {
        s.status = "won";
        s.flashlight = false;
        s.monitor = false;
        s.ending = s.notes.length === 3 ? "archive" : "dawn";
        this.emit("won", { ending: s.ending });
        return;
      }
      if (s.outage) {
        s.outageTimer -= dt;
        if (s.outageTimer <= 0) this.lose("power");
        return;
      }
      const drain =
        0.105 +
        (s.monitor ? 0.115 : 0) +
        (s.door ? 0.49 : 0) +
        (s.flashlight ? 0.37 : 0);
      s.power = Math.max(0, s.power - drain * dt);
      if (s.power <= 0) {
        s.outage = true;
        s.monitor = false;
        s.door = false;
        s.flashlight = false;
        this.emit("outage");
        return;
      }
      if (s.power <= 25 && !s.lowWarning) {
        s.lowWarning = true;
        this.emit("lowPower");
      }
      if (s.power <= 10 && !s.criticalWarning) {
        s.criticalWarning = true;
        this.emit("criticalPower");
      }
      const shadow = s.shadow;
      if (shadow.stage === 3) {
        if (s.door) {
          shadow.repel += dt;
          if (shadow.repel >= 2.8) {
            shadow.stage = -1;
            shadow.timer = this.between(18, 24) - this.hour * 0.8;
            shadow.repel = 0;
            s.doorRepels += 1;
            this.emit("shadowRepelled");
          }
        } else {
          shadow.repel = 0;
          shadow.attack -= dt;
          if (shadow.attack <= 0) {
            this.lose("shadow");
            return;
          }
        }
      } else {
        const watched =
          shadow.stage >= 0 &&
          s.monitor &&
          s.camera === SHADOW_CAMERAS[shadow.stage];
        shadow.timer -= dt * (watched ? 0.18 : 1);
        if (shadow.timer <= 0) {
          shadow.stage += 1;
          shadow.timer = this.between(13, 18) - this.hour * 0.9;
          if (shadow.stage === 3) {
            shadow.attack = Math.max(6.5, 9 - this.hour * 0.35);
            shadow.repel = 0;
            this.emit("doorDanger");
          } else this.emit("shadowMoved", { stage: shadow.stage });
        }
      }
      const whisper = s.whisper;
      if (whisper.active) {
        if (s.flashlight && !s.monitor) {
          whisper.repel += dt;
          if (whisper.repel >= 2.2) {
            whisper.active = false;
            whisper.timer = this.between(34, 46) - this.hour * 0.7;
            whisper.repel = 0;
            s.ventRepels += 1;
            this.emit("whisperRepelled");
          }
        } else whisper.repel = Math.max(0, whisper.repel - dt * 0.25);
        whisper.attack -= dt;
        if (whisper.active && whisper.attack <= 0) this.lose("whisper");
      } else {
        whisper.timer -= dt;
        if (whisper.timer <= 0) {
          whisper.active = true;
          whisper.attack = Math.max(10, 15 - this.hour * 0.6);
          whisper.repel = 0;
          this.emit("ventDanger");
        }
      }
    }
  }
  return {
    ShiftEngine,
    CAMERA_NAMES,
    SHADOW_CAMERAS,
    NOTE_TIMES,
    NOTE_CAMERAS,
  };
});
