# Credits

## Original project material

- Game concept, writing, rules, UI, SVG surveillance environments, geometric shadow characters, icon drawings, Android host and procedural sound: created for **The Last Shift**.
- `game/assets/security-office.jpg`: AI-generated environment artwork created for this project. No third-party game art or recorded sound is used. No exclusive copyright in the generated image is claimed.
- The story, factory and people are fictional. This project is not affiliated with any real factory, security company or existing horror-game franchise.

## Bundled fonts

Fonts were downloaded from the Google Fonts source repository and are bundled locally; the running game never contacts Google Fonts.

| Font | Source | License file |
| --- | --- | --- |
| Noto Sans Bengali | https://github.com/google/fonts/tree/main/ofl/notosansbengali | `game/assets/NotoSansBengali-OFL.txt` |
| Barlow Condensed | https://github.com/google/fonts/tree/main/ofl/barlowcondensed | `game/assets/BarlowCondensed-OFL.txt` |
| Space Mono | https://github.com/google/fonts/tree/main/ofl/spacemono | `game/assets/SpaceMono-OFL.txt` |

Fonts retain their upstream copyrights and SIL Open Font License terms. Original font binaries are unmodified.

## Tooling

- Native host uses the Android framework and the device’s Android System WebView.
- Google Android SDK tools are downloaded separately for builds and are **not** redistributed with the source ZIP.
- Playwright is an optional development/test dependency, not bundled in the APK.
